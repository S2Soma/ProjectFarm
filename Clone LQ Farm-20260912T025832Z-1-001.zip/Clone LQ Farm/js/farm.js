/* ============================================================
   farm.js — isometric field built from the painted plot tiles

   A 4x4 field of hand-painted isometric plots sits on a CSS island.
   Rendering is incremental: each plot's DOM is built once and a tick
   only writes the countdown text.
   ============================================================ */
(function (global) {
  'use strict';
  const D = global.DATA, GS = global.GS, A = global.ASSETS;
  const S = GS.S;

  /* ---- isometric layout ---- */
  const TW = 176, TH = 88;            // tile footprint
  const HW = TW / 2, HH = TH / 2;
  const OX = 600, OY = 200;           // centre of plot (0,0)

  const $ = s => document.querySelector(s);
  const gridEl = () => $('#farmGrid');
  const fxEl = () => $('#fxLayer');

  const view = [];
  /* Everything in the scene shares one depth scale, biased so nothing can
     go negative: a negative z-index paints behind .island / .sky / .water,
     which made the two props behind the field vanish outright. */
  const BASE_Z = 30;
  const depth = (r, c) => BASE_Z + Math.round((r + c) * 10);
  const depthAtY = y => BASE_Z + Math.round(((y - OY) / HH) * 10);

  function cellPos(i) {
    const r = Math.floor(i / 4), c = i % 4;
    return { x: OX + (c - r) * HW, y: OY + (c + r) * HH, r, c };
  }

  /* ------------------------------------------------------------
     scenery around the field
     ------------------------------------------------------------ */
  function buildScenery() {
    const deco = $('#deco');
    if (!deco || deco.dataset.built) return;
    deco.dataset.built = '1';

    /* ------------------------------------------------------------
       Props sit on the grass ring between the field and the island
       edge. Hand-picked coordinates kept landing on plots because the
       ring is only as wide as the island exceeds the field, and that
       margin is far thinner along the vertical axis than the
       horizontal one. Place them parametrically instead.

       FIELD_A/B are the field diamond's half-extents including the
       tile art; ISLAND_A/B are the island's. A prop at ring radius
       r > 1 is outside the field; r < ISLAND_A/FIELD_A keeps it on
       the island.
       ------------------------------------------------------------ */
    const P = A.PROP;
    /* field centre = OY + 3*HH; the island is concentric with it */
    const CX = OX, CY = OY + 3 * HH;
    const FIELD_A = 354, FIELD_B = 206;

    /* u walks the diamond perimeter 0..1 (0 = right vertex, going down) */
    function ringPos(u, r) {
      const t = ((u % 1) + 1) % 1;
      const q = Math.floor(t * 4), f = t * 4 - q;      // quadrant + fraction
      let fx, fy;
      if (q === 0) { fx = 1 - f; fy = f; }              // right  -> bottom
      else if (q === 1) { fx = -f; fy = 1 - f; }        // bottom -> left
      else if (q === 2) { fx = -(1 - f); fy = -f; }     // left   -> top
      else { fx = f; fy = -(1 - f); }                   // top    -> right
      return { x: Math.round(CX + r * FIELD_A * fx), y: Math.round(CY + r * FIELD_B * fy) };
    }

    /* [perimeter position, radius, sprite, width]
       u: 0 = right vertex, .25 = bottom, .5 = left, .75 = top.
       The ground is a thin sliver at each vertex, so only short props
       (rock, haystack) go near u = .25 and u = .75; tall ones sit on
       the long edges where there is grass under and behind them. */
    const props = [
      /* One fence per side only: two placed either side of a vertex sat
         ~40px apart at mismatched scales and read as a duplicated,
         glitched fence rather than a turned corner. Tall props also stay
         clear of u = .25 and .75, where the grass is a thin sliver. */
      [0.05, 1.17, P.fence,     102],
      [0.17, 1.18, P.haystack,   86],
      [0.28, 1.14, P.rock,       62],
      [0.39, 1.17, P.banner,     60],
      [0.50, 1.18, P.haystack,   84],
      [0.59, 1.17, P.fenceLamp, 104],
      [0.68, 1.18, P.signpost,   72],
      [0.78, 1.13, P.rock,       58],
      [0.89, 1.16, P.rock,       66]    ];
    let html = '';
    props.forEach(([u, r, src, w]) => {
      const { x, y } = ringPos(u, r);
      /* depth from the foot point, on the same scale the plots use */
      const z = depthAtY(y);
      html += `<img src="${src}" class="prop" alt="" draggable="false"
        style="left:${x}px;top:${y}px;width:${w}px;z-index:${z}">`;
    });    deco.innerHTML = html;

    const sky = $('#skyProps');
    if (sky) {
      let s = '';
      [[6, 40, 150, 26], [58, 16, 120, 34], [80, 62, 170, 20]].forEach(([x, y, w, dur], k) => {
        s += `<div class="cloud" style="left:${x}%;top:${y}px;width:${w}px;
          animation-duration:${dur}s;animation-delay:-${k * 9}s"></div>`;
      });
      sky.innerHTML = s;
    }

    let p = '';
    for (let i = 0; i < 16; i++) {
      p += `<div class="petal" style="left:${(Math.random() * 118) | 0}%;
        animation-duration:${(8 + Math.random() * 8).toFixed(1)}s;
        animation-delay:-${(Math.random() * 14).toFixed(1)}s;
        opacity:${(0.4 + Math.random() * 0.5).toFixed(2)}"></div>`;
    }
    $('#petals').innerHTML = p;

    const w = $('#waterFx');
    if (w) {
      let s = '';
      for (let i = 0; i < 12; i++)
        s += `<i style="left:${(Math.random() * 100).toFixed(1)}%;top:${(62 + Math.random() * 34).toFixed(1)}%;
          animation-delay:-${(Math.random() * 5).toFixed(1)}s"></i>`;
      w.innerHTML = s;
    }

    A.preload([A.TILE.empty, A.TILE.locked, A.TILE.watered, A.TILE.ready].concat(A.GENERIC));
  }

  /* ------------------------------------------------------------
     plots
     ------------------------------------------------------------ */
  function buildGrid() {
    const g = gridEl();
    g.textContent = '';
    view.length = 0;

    for (let i = 0; i < 16; i++) {
      const { x, y, r, c } = cellPos(i);
      const el = document.createElement('div');
      el.className = 'plot';
      el.dataset.i = i;
      el.style.cssText = `left:${x}px;top:${y}px;width:${TW}px;height:${TH}px;z-index:${depth(r, c)}`;
      el.innerHTML =
        `<img class="ptile" src="${A.TILE.empty}" alt="" draggable="false">` +
        `<div class="phit"></div>` +
        `<div class="content">` +
          `<div class="aura" hidden></div>` +
          `<img class="crop" alt="" draggable="false" decoding="async" hidden>` +
          `<img class="fruit" alt="" draggable="false" decoding="async" hidden>` +
          `<div class="plot-badge" hidden></div>` +
          `<div class="plot-timer" hidden></div>` +
          `<div class="plot-water" hidden></div>` +
        `</div>`;
      g.appendChild(el);

      view.push({
        el,
        tile: el.querySelector('.ptile'),
        crop: el.querySelector('.crop'),
        fruit: el.querySelector('.fruit'),
        aura: el.querySelector('.aura'),
        badge: el.querySelector('.plot-badge'),
        timer: el.querySelector('.plot-timer'),
        water: el.querySelector('.plot-water'),
        sCrop: null, sStage: -1, sVar: -1, sState: '', sTile: '', sTimer: '', sWatered: null
      });
      el.style.setProperty('--sway', ((i * 137) % 1000 / 1000 * -2.8).toFixed(2) + 's');
    }

    g.addEventListener('click', ev => {
      const p = ev.target.closest('.plot');
      if (!p) return;
      ev.stopPropagation();
      global.UI.openPlot(+p.dataset.i, p);
    });
  }

  function plotState(p) {
    if (!p || p.locked) return 'locked';
    if (!p.crop) return 'empty';
    return elapsed(p) >= p.dur ? 'ready' : 'growing';
  }
  const elapsed = p => (Date.now() - p.plantedAt) / 1000 + (p.bonus || 0);
  const remain = p => Math.max(0, Math.ceil(p.dur - elapsed(p)));
  function stageOf(p) {
    const t = elapsed(p) / p.dur;
    if (t >= 1) return 3;
    if (t >= 0.62) return 2;
    if (t >= 0.28) return 1;
    return 0;
  }
  function fmt(sec) {
    if (sec >= 3600) return Math.floor(sec / 3600) + 'g ' + Math.floor((sec % 3600) / 60) + 'p';
    if (sec >= 60) return Math.floor(sec / 60) + 'p ' + (sec % 60) + 's';
    return sec + 's';
  }

  function renderPlot(i) {
    const v = view[i], p = S.plots[i];
    if (!v) return;
    const st = plotState(p);

    /* the sheet ships a watered tile, so watering now reads on the ground */
    const tileKey = st === 'locked' ? 'locked'
      : st === 'ready' ? 'ready'
      : (p && p.watered) ? 'watered' : 'empty';
    if (v.sState !== st || v.sTile !== tileKey) {
      v.el.classList.toggle('locked', st === 'locked');
      v.el.classList.toggle('ready', st === 'ready');
      v.tile.src = A.TILE[tileKey];
      v.sState = st; v.sTile = tileKey;
    }

    if (st === 'locked' || st === 'empty') {
      if (v.sCrop !== null) {
        v.crop.hidden = true; v.crop.removeAttribute('src');
        v.fruit.hidden = true; v.fruit.removeAttribute('src');
        v.aura.hidden = true; v.badge.hidden = true;
        v.timer.hidden = true; v.water.hidden = true;
        v.sCrop = null; v.sStage = -1; v.sVar = -1; v.sTimer = ''; v.sWatered = null;
      }
      return;
    }

    const seed = D.SEED_BY_ID[p.crop];
    const stage = stageOf(p);
    const variant = stage === 3 ? (p.variant || 0) : 0;

    if (v.sCrop !== p.crop || v.sStage !== stage || v.sVar !== variant) {
      /* A mutation keeps its own crop art, tinted, with a glow behind
         it. Swapping in the sheet's crystal sprites hid which crop it
         was, repeated the same blob for several variants, and clashed
         with the painted vegetables. */
      v.crop.hidden = false;
      v.crop.src = A.plant(seed.art, stage, variant);
      v.crop.style.height = A.STAGE_H[stage] + 'px';
      v.crop.className = 'crop grow-' + stage + (variant ? ' mutated' : '');
      v.crop.style.filter = A.variantFilter(seed.art, variant);

      const fr = stage === 3 ? A.fruit(seed.art) : null;
      if (fr) {
        v.fruit.hidden = false;
        v.fruit.src = fr;
        v.fruit.style.filter = A.variantFilter(seed.art, variant);
      } else v.fruit.hidden = true;

      if (v.sStage !== -1 && v.sStage !== stage) {
        v.crop.classList.remove('pop');
        clearTimeout(v.popT);
        requestAnimationFrame(() => {
          v.crop.classList.add('pop');
          v.popT = setTimeout(() => v.crop.classList.remove('pop'), 520);
        });
      }
      const g = A.elem(variant).glow;
      if (g) { v.aura.hidden = false; v.aura.style.setProperty('--au', g); }
      else v.aura.hidden = true;

      v.sCrop = p.crop; v.sStage = stage; v.sVar = variant;
    }

    if (st === 'ready') {
      if (v.badge.hidden) { v.badge.hidden = false; v.timer.hidden = true; v.water.hidden = true; v.sTimer = ''; }
    } else {
      if (!v.badge.hidden) { v.badge.hidden = true; v.timer.hidden = false; }
      const txt = fmt(remain(p));
      if (txt !== v.sTimer) { v.timer.textContent = txt; v.sTimer = txt; }
      const wet = !!p.watered;
      if (v.sWatered !== wet) { v.water.hidden = wet; v.sWatered = wet; }
    }
  }

  function renderAll() { for (let i = 0; i < 16; i++) renderPlot(i); }

  function tickingPlots() {
    const out = [];
    for (let i = 0; i < 16; i++) {
      const p = S.plots[i];
      if (p && p.crop && plotState(p) === 'growing') out.push(i);
    }
    return out;
  }

  /* ------------------------------------------------------------
     actions
     ------------------------------------------------------------ */
  function plant(i, seedId) {
    const p = S.plots[i];
    if (!p || p.locked || p.crop) return false;
    const seed = D.SEED_BY_ID[seedId];
    if (!seed || !GS.takeSeed(seedId, 1)) return false;

    p.crop = seedId;
    p.plantedAt = Date.now();
    p.dur = GS.growTime(seed);
    p.bonus = 0;
    p.watered = false;
    p.variant = GS.rollVariant(seed);

    GS.trackCrop('plant', seedId, 1);
    GS.addEnergy(GS.energyGain(1));
    renderPlot(i);
    puff(i);
    return true;
  }

  function water(i) {
    const p = S.plots[i];
    if (!p || !p.crop || p.watered || plotState(p) === 'ready') return false;
    p.watered = true;
    p.bonus = (p.bonus || 0) + p.dur * 0.25;
    GS.track('water', 1);
    GS.addEnergy(GS.energyGain(2));
    renderPlot(i);
    droplets(i);
    burst(i, '−25%', '#8fd8ff');
    return true;
  }

  function harvest(i) {
    const p = S.plots[i];
    if (!p || plotState(p) !== 'ready') return null;
    const seed = D.SEED_BY_ID[p.crop];
    const v = p.variant || 0;

    flyOff(i, A.icon(seed.art, v), v);

    const xp = GS.xpFor(seed, v);
    GS.addProduce(p.crop, v, 1);
    GS.addXp(xp);
    GS.addEnergy(GS.energyFor(seed, v));
    GS.trackCrop('harvest', p.crop, 1);
    if (v) GS.track('mutate', 1);

    const g = A.elem(v).glow;
    burst(i, `+${xp} XP`, g || '#ffe9a8');
    sparkle(i, v ? 20 : 10, g);

    p.crop = null; p.plantedAt = 0; p.variant = 0; p.watered = false; p.bonus = 0;
    renderPlot(i);
    return { seed, v };
  }

  function instantGrow(i) {
    const p = S.plots[i];
    if (!p || !p.crop) return false;
    p.bonus = p.dur;
    renderPlot(i);
    sparkle(i, 12, '#ffd45e');
    return true;
  }

  /* ------------------------------------------------------------
     effects
     ------------------------------------------------------------ */
  function fx(cls, style, html, life) {
    const d = document.createElement('div');
    d.className = cls;
    d.style.cssText = style;
    if (html) d.innerHTML = html;
    fxEl().appendChild(d);
    setTimeout(() => d.remove(), life);
    return d;
  }

  function burst(i, text, color) {
    const { x, y } = cellPos(i);
    const d = fx('float-txt', `left:${x}px;top:${y - 54}px;color:${color || '#ffe9a8'}`, '', 1300);
    d.textContent = text;
  }

  function sparkle(i, n, color) {
    const { x, y } = cellPos(i);
    for (let k = 0; k < n; k++) {
      const a = Math.random() * Math.PI * 2, r = 32 + Math.random() * 62;
      fx('spark',
        `left:${x}px;top:${y - 26}px;--dx:${(Math.cos(a) * r) | 0}px;--dy:${((Math.sin(a) * r * .6) - 44) | 0}px;` +
        `animation-delay:${(Math.random() * .18).toFixed(2)}s;` +
        (color ? `background:radial-gradient(circle,#fff,${color})` : ''), '', 1200);
    }
  }

  function puff(i) {
    const { x, y } = cellPos(i);
    for (let k = 0; k < 7; k++) {
      const a = (k / 7) * Math.PI * 2;
      fx('puff', `left:${x}px;top:${y}px;--dx:${(Math.cos(a) * 34) | 0}px;--dy:${((Math.sin(a) * 34) * .5) | 0}px;` +
        `animation-delay:${(k * .02).toFixed(2)}s`, '', 800);
    }
  }

  function droplets(i) {
    const { x, y } = cellPos(i);
    for (let k = 0; k < 9; k++)
      fx('drop', `left:${x + (Math.random() * 70 - 35) | 0}px;top:${y - 68}px;` +
        `animation-delay:${(Math.random() * .35).toFixed(2)}s`, '', 1000);
  }

  function flyOff(i, src, variant) {
    if (!src) return;
    const { x, y } = cellPos(i);
    const d = fx('fly-crop',
      `left:${x}px;top:${y - 40}px;` + (variant ? `filter:${A.variantFilter('', variant)}` : ''),
      `<img src="${src}" alt="">`, 900);
    const t = global.ANIM && global.ANIM.toStage($('#btnWarehouse'), 'kho');
    if (t) {
      d.style.setProperty('--tx', (t.x - x).toFixed(0) + 'px');
      d.style.setProperty('--ty', (t.y - (y - 40)).toFixed(0) + 'px');
    }
  }

  global.FARM = {
    buildScenery, buildGrid, renderAll, renderPlot, cellPos, tickingPlots,
    plant, water, harvest, instantGrow,
    plotState, remain, stageOf, fmt, burst, sparkle, puff, droplets,
    TW, TH
  };
})(window);
