/* ============================================================
   anim.js — small animation helpers shared by the UI
   ============================================================ */
(function (global) {
  'use strict';
  const $ = s => document.querySelector(s);

  const easeOut = t => 1 - Math.pow(1 - t, 3);

  /* ---------- number counter ----------
     Tweens an element's text from its current value to a new one.
     Skips the tween for tiny deltas so the HUD never looks busy. */
  const counters = new WeakMap();
  function count(el, to, fmt) {
    if (!el) return;
    fmt = fmt || (n => Math.round(n).toLocaleString('vi-VN'));
    const rec = counters.get(el) || { cur: to, raf: 0 };
    if (rec.cur === to) { if (el.textContent !== fmt(to)) el.textContent = fmt(to); return; }

    const from = rec.cur;
    const delta = Math.abs(to - from);
    if (delta < 2 || delta > 5e6) {            // trivial or absurd → snap
      rec.cur = to; counters.set(el, rec); el.textContent = fmt(to); return;
    }
    cancelAnimationFrame(rec.raf);
    const dur = Math.min(650, 220 + delta * 0.18);
    const t0 = performance.now();
    const step = now => {
      const t = Math.min(1, (now - t0) / dur);
      const v = from + (to - from) * easeOut(t);
      el.textContent = fmt(v);
      if (t < 1) rec.raf = requestAnimationFrame(step);
      else { rec.cur = to; el.textContent = fmt(to); }
    };
    rec.cur = to;
    counters.set(el, rec);
    rec.raf = requestAnimationFrame(step);

    // brief highlight so gains are noticed (class toggled across a frame
    // boundary instead of via a forced reflow read)
    if (to > from) {
      el.classList.remove('bump');
      requestAnimationFrame(() => el.classList.add('bump'));
      setTimeout(() => el.classList.remove('bump'), 520);
    }
  }

  /* ------------------------------------------------------------
     Geometry cache.
     Reading getBoundingClientRect right after mutating the DOM
     forces a synchronous reflow; doing it several times inside a
     tap handler cost ~60ms. Stage and HUD targets only move when
     the viewport changes, so they are measured once and reused,
     and callers that already know a point pass it directly.
     ------------------------------------------------------------ */
  let geom = null;
  const targetCache = new Map();

  function invalidate() { geom = null; targetCache.clear(); }
  window.addEventListener('resize', invalidate);
  window.addEventListener('orientationchange', invalidate);
  if (window.visualViewport) window.visualViewport.addEventListener('resize', invalidate);

  function stageGeom() {
    if (geom) return geom;
    const st = $('#stage');
    if (!st) return null;
    const r = st.getBoundingClientRect();
    geom = { left: r.left, top: r.top, sc: (r.width / 1200) || 1 };
    return geom;
  }

  /* element (or {x,y} already in stage space) → stage coordinates */
  function toStage(ref, cacheKey) {
    if (!ref) return null;
    if (typeof ref.x === 'number') return ref;
    if (cacheKey && targetCache.has(cacheKey)) return targetCache.get(cacheKey);
    const g = stageGeom();
    if (!g) return null;
    const b = ref.getBoundingClientRect();
    const p = { x: (b.left + b.width / 2 - g.left) / g.sc, y: (b.top + b.height / 2 - g.top) / g.sc };
    if (cacheKey) targetCache.set(cacheKey, p);
    return p;
  }
  /* ---------- coin / xp flying to the HUD ---------- */
  function flyTo(from, to, iconHTML, n, toKey) {
    const fx = $('#fxLayer');
    if (!fx || !from || !to) return;
    const a = toStage(from);
    const b = toStage(to, toKey);
    if (!a || !b) return;

    const frag = document.createDocumentFragment();
    const nodes = [];
    for (let i = 0; i < (n || 6); i++) {
      const d = document.createElement('div');
      d.className = 'fly-coin';
      d.innerHTML = iconHTML;
      const jx = (Math.random() * 44 - 22), jy = (Math.random() * 30 - 26);
      d.style.cssText =
        `left:${a.x.toFixed(0)}px;top:${a.y.toFixed(0)}px;--jx:${jx.toFixed(0)}px;--jy:${jy.toFixed(0)}px;` +
        `--tx:${(b.x - a.x).toFixed(0)}px;--ty:${(b.y - a.y).toFixed(0)}px;` +
        `animation-delay:${(i * 0.055).toFixed(2)}s`;
      frag.appendChild(d);
      nodes.push(d);
    }
    fx.appendChild(frag);
    setTimeout(() => nodes.forEach(d => d.remove()), 1100 + n * 60);

    if (to instanceof Element) {
      setTimeout(() => { to.classList.remove('recv'); to.classList.add('recv'); }, 480);
      setTimeout(() => to.classList.remove('recv'), 960);
    }
  }

  /* ---------- press feedback on any control ---------- */
  function bindPress(root) {
    const sel = 'button, .plot, .seed-cell, .wh-cell, .chest, .shop-card, .pp-seed, .col-item, .fr-row';
    (root || document).addEventListener('pointerdown', e => {
      const t = e.target.closest(sel);
      if (!t || t.disabled) return;
      t.classList.add('pressed');
      const clear = () => t.classList.remove('pressed');
      t.addEventListener('pointerup', clear, { once: true });
      t.addEventListener('pointerleave', clear, { once: true });
      t.addEventListener('pointercancel', clear, { once: true });
    }, { passive: true });
  }

  /* ---------- ripple on buttons ---------- */
  function bindRipple(root) {
    (root || document).addEventListener('pointerdown', e => {
      const t = e.target.closest('.btn-crimson, .btn-gold, .btn-gray, .pp-btn, .btn-claim, .btn-goto, .dia-btn');
      if (!t || t.disabled) return;
      const r = t.getBoundingClientRect();
      const d = document.createElement('span');
      d.className = 'ripple';
      const size = Math.max(r.width, r.height) * 1.6;
      d.style.cssText = `width:${size}px;height:${size}px;left:${e.clientX - r.left - size / 2}px;top:${e.clientY - r.top - size / 2}px`;
      t.appendChild(d);
      setTimeout(() => d.remove(), 620);
    }, { passive: true });
  }

  /* ---------- stagger children in ---------- */
  function stagger(container, sel, step) {
    if (!container) return;
    container.querySelectorAll(sel).forEach((el, i) => {
      el.style.setProperty('--i', i);
      el.classList.add('stagger-in');
      el.style.animationDelay = (i * (step || 0.04)).toFixed(2) + 's';
    });
  }

  /* ---------- screen shake ---------- */
  function shake(power) {
    const s = $('#shakeWrap') || $('#stage');
    if (!s) return;
    s.style.setProperty('--shake', (power || 4) + 'px');
    s.classList.remove('shaking');
    requestAnimationFrame(() => s.classList.add('shaking'));   // no forced reflow
    setTimeout(() => s.classList.remove('shaking'), 480);
  }

  global.ANIM = { count, flyTo, bindPress, bindRipple, stagger, shake, easeOut, toStage, stageGeom, invalidate };
})(window);
