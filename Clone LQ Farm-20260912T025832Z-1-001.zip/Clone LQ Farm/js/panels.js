/* ============================================================
   panels.js — every screen from the reference design
   ============================================================ */
(function (global) {
  'use strict';
  const D = global.DATA, GS = global.GS, A = global.ASSETS, FARM = global.FARM, ANIM = global.ANIM;
  const S = GS.S;
  const $ = s => document.querySelector(s);
  const $$ = s => Array.prototype.slice.call(document.querySelectorAll(s));
  const num = n => (n | 0).toLocaleString('vi-VN');

  let current = null;          // open panel id
  let selSeed = null;          // seeds panel selection
  let selChest = 2;            // magic panel selection
  let msTab = 'main', whTab = 'crop', frTab = 'list', shopTab = 'coin';
  let popPlot = -1;

  /* ============ toast ============ */
  /* The strip is docked in the 78px band below the panels; a third
     stacked toast would reach back up over the panel frame. */
  const TOAST_MAX = 2;
  function toast(msg) {
    const wrap = $('#toasts');
    while (wrap.children.length >= TOAST_MAX) wrap.firstElementChild.remove();
    const t = document.createElement('div');
    t.className = 'toast'; t.textContent = msg;
    wrap.appendChild(t);
    setTimeout(() => t.remove(), 2100);
  }

  /* ============ overlay control ============ */
  function open(id) {
    closePop();
    $$('.panel,.page').forEach(p => p.classList.remove('on', 'closing'));
    const el = $('#p-' + id);
    if (!el) return;
    el.classList.add('on');
    $('#overlay').classList.add('on');
    current = id;
    render(id);
    requestAnimationFrame(markScrollers);
  }
  function close() {
    const openEls = $$('.panel.on,.page.on');
    if (!openEls.length) { closePop(); return; }
    openEls.forEach(p => p.classList.add('closing'));
    $('#overlay').classList.remove('on');
    $('#upTip').classList.remove('on');
    current = null;
    closePop();
    setTimeout(() => openEls.forEach(p => p.classList.remove('on', 'closing')), 170);
  }
  function render(id) {
    ({ upgrade: renderUpgrade, magic: renderMagic, missions: renderMissions,
       warehouse: renderWarehouse, seeds: renderSeeds, friends: renderFriends,
       shop: renderShop, collection: renderCollection }[id] || (() => {}))();
  }
  function refresh() { if (current) render(current); }

  /* Mark every scrollable list so CSS can fade the cut edge — without a
     cue, half the seed grid and two whole collection sets simply looked
     absent. Re-run after each render and on scroll. */
  function markScrollers() {
    $$('.scroller, .pp-seeds').forEach(el => {
      const upd = () => {
        el.classList.toggle('more-below', el.scrollHeight - el.clientHeight - el.scrollTop > 4);
        el.classList.toggle('more-above', el.scrollTop > 4);
      };
      if (!el.dataset.scrollCue) {
        el.dataset.scrollCue = '1';
        el.addEventListener('scroll', upd, { passive: true });
      }
      upd();
    });
  }

  /* ============ reward popup ============ */
  function reward(title, items) {
    $('#rwTitle').textContent = title;
    $('#rwItems').innerHTML = items.map(it => `
      <div class="rw-item"><div class="bx">${it.art || `<i class="ic ${it.ic}"></i>`}</div>
      <em>${it.label}</em></div>`).join('');
    const m = $('#rewardModal');
    m.classList.add('on');
    /* the panel underneath keeps its close button on screen but
       unreachable, so hide it while the reward is up */
    document.body.classList.add('reward-up');
    ANIM.stagger($('#rwItems'), '.rw-item', 0.09);
    ANIM.shake(3);
  }
  function closeReward() {
    const m = $('#rewardModal');
    if (!m.classList.contains('on')) return;
    m.classList.add('closing');
    document.body.classList.remove('reward-up');
    setTimeout(() => m.classList.remove('on', 'closing'), 180);
  }

  /* main.js registers a callback so the loop re-scans which plots tick */
  let dirtyHook = () => {};
  function setDirtyHook(fn) { dirtyHook = fn || (() => {}); }

  /* ============================================================
     HUD
     ============================================================ */
  const hudLast = {};
  function renderHUD(snap) {
    if (hudLast.lv !== S.lv) { hudLast.lv = S.lv; $('#hudLevel').textContent = S.lv; }

    if (snap) {
      $('#hudCoin').textContent = num(S.coin);
      $('#shopCoin').textContent = num(S.coin);
    } else {
      ANIM.count($('#hudCoin'), S.coin);
      ANIM.count($('#shopCoin'), S.coin);
    }

    const xpPct = Math.min(100, S.xp / GS.xpNeed() * 100);
    if (hudLast.xp !== xpPct) { hudLast.xp = xpPct; $('#hudXpFill').style.width = xpPct + '%'; }

    const en = num(S.energy) + '/' + num(GS.energyGoal());
    if (hudLast.en !== en) { hudLast.en = en; $('#hudEnergy').textContent = en; }

    const col = GS.collectedCount() + '/135';
    if (hudLast.col !== col) { hudLast.col = col; $('#hudCollect').textContent = col; }

    const m = GS.activeMission();
    const mt = m ? `${m.t.t} (${m.pr.p}/${m.t.need})` : 'Đã hoàn thành mọi nhiệm vụ';
    if (hudLast.ms !== mt) { hudLast.ms = mt; $('#hudMission').textContent = mt; }
  }

  /* fire coins/xp from a source element toward their HUD counters */
  /* `from` may be an element or a {x,y} point already in stage space —
     plots pass their known cell centre so no layout read is needed. */
  function payout(from, coin, xp) {
    const src = from || { x: 600, y: 270 };
    if (coin) ANIM.flyTo(src, $('#btnCoin'), `<i class="ic ic-coin"></i>`, 7, 'coin');
    if (xp) setTimeout(() => ANIM.flyTo(src, $('.lvbar'), `<i class="ic ic-xp"></i>`, 5, 'xp'), 120);
  }

  /* ============================================================
     PLOT POPUP
     ============================================================ */
  function closePop() { $('#plotPop').classList.remove('on'); popPlot = -1; }

  function openPlot(i, el) {
    const p = S.plots[i];
    const st = FARM.plotState(p);
    popPlot = i;

    if (st === 'ready') { doHarvest(i); return; }

    const pop = $('#plotPop');
    let html = '';

    if (st === 'locked') {
      const need = D.SEEDS.length && S.lv;
      html = `<div class="pp-title">Ô đất bị khóa</div>
        <div class="pp-sub">Nâng cấp trang trại để mở thêm ô đất</div>
        <div class="pp-acts">
          <button class="pp-btn" data-act="upgrade">Nâng cấp</button>
          <button class="pp-btn alt" data-act="buyplot">Mở khóa · 12.000</button>
        </div>`;
    } else if (st === 'growing') {
      const seed = D.SEED_BY_ID[p.crop];
      html = `<div class="pp-title">${seed.name}${p.variant ? ' ✦ ' + A.elem(p.variant).name : ''}</div>
        <div class="pp-sub">Còn ${FARM.fmt(FARM.remain(p))} · giai đoạn ${FARM.stageOf(p) + 1}/4</div>
        <div class="pp-acts">
          <button class="pp-btn" data-act="water" ${p.watered ? 'disabled' : ''}>Tưới nước</button>
          <button class="pp-btn alt" data-act="speed">Chín ngay · 800</button>
        </div>`;
    } else {
      const owned = Object.entries(S.seeds).filter(([, n]) => n > 0);
      html = `<div class="pp-title">Chọn hạt giống</div>`;
      if (!owned.length) {
        html += `<div class="pp-sub">Bạn chưa có hạt giống nào</div>
          <div class="pp-acts"><button class="pp-btn" data-act="shopseed">Mua hạt giống</button></div>`;
      } else {
        html += `<div class="pp-sub">Chạm để gieo trồng</div><div class="pp-seeds">` +
          owned.map(([id, n]) => {
            const s = D.SEED_BY_ID[id];
            return `<div class="pp-seed r${s.r}" data-seed="${id}" title="${s.name}">
              <img src="${A.icon(s.art, 0)}" alt=""><b>${n}</b></div>`;
          }).join('') + `</div>
          <div class="pp-acts" style="margin-top:6px">
            <button class="pp-btn alt" data-act="shopseed">Cửa hàng hạt</button>
            <button class="pp-btn alt" data-act="plantall">Gieo tất cả</button>
          </div>`;
      }
    }

    pop.innerHTML = html;
    const r = el.getBoundingClientRect(), sr = $('#stage').getBoundingClientRect();
    const sc = sr.width / 1200;
    pop.classList.add('on');
    requestAnimationFrame(markScrollers);
    const px = (r.left + r.width / 2 - sr.left) / sc;
    const py = (r.top - sr.top) / sc - 4;
    pop.style.left = px + 'px';
    pop.style.top = py + 'px';
    /* clamp inside the 1200x620 stage: the popup is anchored bottom-centre,
       so a back-row plot pushed its title off the top edge */
    const pw = pop.offsetWidth, ph = pop.offsetHeight;
    pop.style.left = Math.max(pw / 2 + 6, Math.min(1200 - pw / 2 - 6, px)) + 'px';
    pop.style.top = Math.max(ph + 8, py) + 'px';

    /* A tap that lands on the popup but not on a control used to do nothing
       while the popup stayed open, and the popup covered other plots — so the
       next chip tap planted on the old tile. Close on any dead area. */
    pop.onclick = ev => {
      if (!ev.target.closest('[data-seed]') && !ev.target.closest('[data-act]')) closePop();
    };
    pop.querySelectorAll('[data-seed]').forEach(b =>
      b.addEventListener('click', () => { doPlant(i, b.dataset.seed); }));
    pop.querySelectorAll('[data-act]').forEach(b =>
      b.addEventListener('click', () => popAction(b.dataset.act, i)));
  }

  function popAction(act, i) {
    if (act === 'water') { if (FARM.water(i)) { renderHUD(); GS.save(); } closePop(); }
    else if (act === 'speed') {
      if (S.coin < 800) return toast('Không đủ xu nông trại');
      GS.addCoin(-800); FARM.instantGrow(i); renderHUD(); GS.save(); closePop();
      toast('Cây đã chín ngay lập tức!');
    }
    else if (act === 'upgrade') { open('upgrade'); }
    else if (act === 'buyplot') {
      if (S.coin < 12000) return toast('Không đủ xu nông trại');
      if (GS.unlockExtraPlot(i)) { GS.addCoin(-12000); FARM.renderAll(); dirtyHook(); renderHUD(); GS.save(); toast('Đã mở khóa ô đất này!'); }
      closePop();
    }
    else if (act === 'shopseed') { open('seeds'); }
    else if (act === 'plantall') { plantAll(D.SEED_BY_ID[Object.keys(S.seeds)[0]]?.id); closePop(); }
  }

  function doPlant(i, seedId) {
    if (FARM.plant(i, seedId)) { dirtyHook(); renderHUD(); GS.save(); }
    closePop();
  }
  function plantAll(preferred) {
    let n = 0;
    for (let i = 0; i < 16; i++) {
      if (FARM.plotState(S.plots[i]) !== 'empty') continue;
      const id = (preferred && S.seeds[preferred]) ? preferred : Object.keys(S.seeds).find(k => S.seeds[k] > 0);
      if (!id) break;
      if (FARM.plant(i, id)) n++;
    }
    if (n) { toast(`Đã gieo ${n} hạt giống`); dirtyHook(); renderHUD(); GS.save(); }
    else toast('Không còn hạt giống');
  }
  function doHarvest(i) {
    const res = FARM.harvest(i);
    if (!res) return;
    dirtyHook(); renderHUD(); GS.save();
    payout(FARM.cellPos(i), 0, res.seed.xp);
    if (res.v) { toast(`✦ Đột biến! ${res.seed.name} ${A.elem(res.v).name}`); ANIM.shake(5); }
  }
  function harvestAll() {
    let n = 0;
    for (let i = 0; i < 16; i++) if (FARM.plotState(S.plots[i]) === 'ready') { FARM.harvest(i); n++; }
    if (n) { toast(`Đã thu hoạch ${n} cây trồng`); dirtyHook(); renderHUD(); GS.save(); ANIM.shake(4); }
    else toast('Chưa có cây nào chín');
  }

  /* ============================================================
     UPGRADE
     ============================================================ */
  function renderUpgrade() {
    const a = D.levelInfo(S.lv), b = D.levelInfo(S.lv + 1);
    $('#upLvA').textContent = S.lv;
    $('#upLvB').textContent = S.lv + 1;
    $('#upFill').style.width = Math.min(100, S.xp / a.xpNeed * 100) + '%';
    $('#upNum').textContent = num(Math.min(S.xp, a.xpNeed)) + '/' + num(a.xpNeed);

    const pct = v => (v * 100).toFixed(2) + '%';
    const row = (label, x, y) =>
      `<div><span>${label}</span><b>${x}</b><i class="arw"></i><b>${y}</b></div>`;
    $('#upEffects').innerHTML =
      row('Thời gian chín được rút ngắn', pct(a.growCut), pct(b.growCut)) +
      row('Xác suất đột biến tăng lên', pct(a.mutate), pct(b.mutate)) +
      row('Giá nông sản tăng', pct(a.priceUp), pct(b.priceUp)) +
      row('Tăng cường năng lượng kỳ diệu', pct(a.energyUp), pct(b.energyUp));

    const nxt = D.SEEDS.find(s => s.lv === S.lv + 1);
    $('#upUnlock').innerHTML = nxt
      ? `<img class="pack" src="${A.icon(nxt.art, 0)}" alt=""><em>${nxt.name}</em>`
      : (b.plots > a.plots ? `<div class="pack" style="width:52px;height:56px;margin:0 auto"></div><em>+1 ô đất trồng</em>`
                           : `<em style="color:#a07a4c">Không có nội dung mới</em>`);

    $('#upMat').innerHTML = A.img(A.crop('banana')) + `<b>${Math.min(5, Math.floor(S.coin / 40000))}/5</b>`;
    $('#upCost').textContent = num(a.cost);
    const can = S.coin >= a.cost && S.xp >= a.xpNeed;
    $('#btnDoUpgrade').classList.toggle('ok', can);

    $('#tipA').textContent = pct(a.growCut);
    $('#tipB').textContent = pct(a.mutate);
    $('#tipC').textContent = pct(a.priceUp);
    $('#tipD').textContent = pct(a.energyUp);
    $('#tipE').textContent = a.plots + ' sào';
  }

  function doUpgrade() {
    const a = D.levelInfo(S.lv);
    if (S.xp < a.xpNeed) return toast('Chưa đủ kinh nghiệm — hãy thu hoạch thêm!');
    if (S.coin < a.cost) return toast('Không đủ xu nông trại');
    const before = GS.maxPlots();
    if (!GS.levelUp()) return;
    FARM.renderAll(); dirtyHook(); renderHUD(); renderUpgrade(); GS.save(); ANIM.shake(7);

    const items = [{ ic: 'ic-house', label: 'Trang trại Lv.' + S.lv }];
    const nxt = D.SEEDS.find(s => s.lv === S.lv);
    if (nxt) items.push({ art: A.img(A.icon(nxt.art, 0)), label: nxt.name });
    if (GS.maxPlots() > before) items.push({ ic: 'ic-box', label: '+1 ô đất' });
    reward('Nâng cấp thành công!', items);
  }

  /* ============================================================
     MAGIC / CHESTS
     ============================================================ */
  let chestPicked = false;
  function renderMagic() {
    const tier = GS.chestTier();
    // first open lands on the tier the energy bar is currently filling
    if (!chestPicked) { selChest = tier; chestPicked = true; }
    $('#chestRow').innerHTML = D.CHESTS.map((c, i) => `
      <div class="chest ${c.cls} ${i === selChest ? 'sel' : ''} ${i > tier ? 'locked' : ''}" data-c="${i}">
        <div class="cbox"><img src="${A.UI.badgeChest}" alt=""></div><div class="cnt">x${S.chests[i]}</div>
      </div>`).join('');
    $$('#chestRow .chest').forEach(el => el.addEventListener('click', () => {
      selChest = +el.dataset.c; renderMagic();
    }));
    const c = D.CHESTS[selChest];
    $('#chestName').textContent = c.name;
    $('#chestDesc').textContent = c.desc;
    const n = S.chests[selChest];
    $('#btnOpenChest').textContent = `Mở tất cả x${n}`;
    $('#btnOpenChest').disabled = n <= 0;
  }

  function openChests() {
    const n = S.chests[selChest];
    if (n <= 0) return toast('Bạn chưa có rương loại này');
    const tierMul = [1, 2, 3.5, 7][selChest];
    let coin = 0, gotSeeds = {};
    for (let k = 0; k < n; k++) {
      coin += Math.round((600 + Math.random() * 1800) * tierMul);
      const rare = Math.random() < [0.10, 0.20, 0.25, 1][selChest];
      const pool = D.SEEDS.filter(s => s.lv <= S.lv + (rare ? 4 : 0) && (rare ? s.r >= 2 : s.r <= 1));
      const pick = (pool.length ? pool : D.SEEDS)[Math.floor(Math.random() * (pool.length || D.SEEDS.length))];
      const qty = rare ? 2 : 3;
      GS.addSeed(pick.id, qty);
      gotSeeds[pick.id] = (gotSeeds[pick.id] || 0) + qty;
    }
    S.chests[selChest] = 0;
    GS.addCoin(coin);
    GS.track('chest', n);
    GS.addEnergy(GS.energyGain(n * 3));
    renderHUD(); renderMagic(); GS.save();
    payout($('#btnOpenChest'), coin, 0);

    const items = [{ ic: 'ic-coin', label: '+' + num(coin) }];
    Object.entries(gotSeeds).slice(0, 4).forEach(([id, q]) => {
      const s = D.SEED_BY_ID[id];
      items.push({ art: A.img(A.icon(s.art, 0)), label: s.name + ' x' + q });
    });
    reward(`Mở ${n} ${D.CHESTS[selChest].name}`, items);
  }

  /* ============================================================
     MISSIONS
     ============================================================ */
  /* open on the chapter the player is actually working through, not a
     hard-coded one — a level-1 player was landing on chapter 3 */
  let chapIdx = -1;
  function activeChapter() {
    for (let i = 0; i < D.CHAPTERS.length; i++)
      if (D.CHAPTERS[i].tasks.some(t => !GS.taskProgress(t, false).claimed)) return i;
    return D.CHAPTERS.length - 1;
  }
  function renderMissions() {
    $$('#msTabs .stab').forEach(b => b.classList.toggle('active', b.dataset.tab === msTab));
    const daily = msTab === 'daily';
    $('#chapterBar').style.display = daily ? 'none' : '';

    let tasks;
    if (daily) tasks = D.DAILY;
    else {
      if (chapIdx < 0) chapIdx = activeChapter();
      chapIdx = Math.max(0, Math.min(D.CHAPTERS.length - 1, chapIdx));
      const ch = D.CHAPTERS[chapIdx];
      $('#chNum').textContent = 'Chương ' + (chapIdx + 1);
      $('#chName').textContent = ch.name;
      tasks = ch.tasks;
    }

    $('#msList').innerHTML = tasks.map(t => {
      const pr = GS.taskProgress(t, daily);
      const done = pr.p >= t.need;
      const act = pr.claimed
        ? `<div class="ms-lock"></div>`
        : done ? `<button class="btn-claim" data-claim="${t.id}">Nhận</button>`
               : `<button class="btn-goto" data-goto="${t.id}">Đi đến</button>`;
      return `<div class="ms-row">
        <div class="ms-name">${t.t} <i>(${pr.p}/${t.need})</i></div>
        <div class="ms-rw">
          <div class="rw-chip"><i class="ic ic-xp"></i><b>${num(t.xp)}</b></div>
          <div class="rw-chip"><i class="ic ic-coin"></i><b>${num(t.coin)}</b></div>
        </div>
        <div class="ms-act">${act}</div>
      </div>`;
    }).join('');

    $$('#msList [data-claim]').forEach(b => b.addEventListener('click', () => {
      const t = tasks.find(x => x.id === b.dataset.claim);
      if (GS.claimTask(t, daily)) {
        reward('Hoàn thành nhiệm vụ', [
          { ic: 'ic-xp', label: '+' + num(t.xp) },
          { ic: 'ic-coin', label: '+' + num(t.coin) }]);
        payout(b, t.coin, t.xp); renderHUD(); renderMissions(); GS.save();
      }
    }));
    $$('#msList [data-goto]').forEach(b => b.addEventListener('click', () => { close(); toast('Hãy làm việc trên nông trại!'); }));
  }

  /* ============================================================
     WAREHOUSE
     ============================================================ */
  function renderWarehouse() {
    $$('#whTabs .stab').forEach(b => b.classList.toggle('active', b.dataset.tab === whTab));
    const g = $('#whGrid');
    if (whTab === 'tool') {
      const tools = Object.entries(S.seeds).filter(([, n]) => n > 0);
      g.innerHTML = tools.length ? tools.map(([id, n]) => {
        const s = D.SEED_BY_ID[id];
        return `<div class="wh-cell r${s.r}" title="${s.name}"><img class="pack" src="${A.icon(s.art, 0)}" alt=""><span class="n">${n}</span></div>`;
      }).join('') : `<div class="wh-empty">Túi hạt giống trống</div>`;
      $('#btnSellAll').textContent = 'Không thể bán';
      $('#btnSellAll').disabled = true;
      return;
    }
    const list = GS.storeList();
    g.innerHTML = list.length ? list.map(it => {
      const s = D.SEED_BY_ID[it.crop];
      return `<div class="wh-cell r${s.r}" title="${s.name}${it.v ? ' ' + A.elem(it.v).name : ''} · ${num(it.price)}">
        <img src="${A.icon(s.art, it ? it.v : 0)}" alt="" style="filter:${A.variantFilter(s.art, it.v)}">
        ${it.v ? `<span class="mut">✦</span>` : ''}<span class="n">${it.n}</span></div>`;
    }).join('') : `<div class="wh-empty">Kho trống — hãy thu hoạch nông sản!</div>`;

    const total = list.reduce((a, b) => a + b.price * b.n, 0);
    $('#btnSellAll').textContent = list.length ? `Bán sỉ · ${num(total)}` : 'Bán sỉ';
    $('#btnSellAll').disabled = !list.length;
  }

  function sellAll() {
    const list = GS.storeList();
    if (!list.length) return toast('Kho trống');
    let total = 0, cnt = 0;
    list.forEach(it => { total += it.price * it.n; cnt += it.n; GS.trackCrop('sellCrop', it.crop, it.n); });
    S.store = {};
    GS.addCoin(total);
    GS.track('sell', cnt);
    renderHUD(); renderWarehouse(); GS.save();
    payout($('#btnSellAll'), total, 0);
    reward('Bán sỉ thành công', [
      { ic: 'ic-coin', label: '+' + num(total) },
      { ic: 'ic-box', label: cnt + ' nông sản' }]);
  }

  /* ============================================================
     SEED SHOP
     ============================================================ */
  function renderSeeds() {
    if (!selSeed) selSeed = D.SEEDS.filter(s => s.lv <= S.lv).slice(-1)[0]?.id || 'turnip';
    $('#seedGrid').innerHTML = D.SEEDS.map(s => {
      const locked = s.lv > S.lv;
      const badge = s.badge === 'exp' ? `<span class="badge exp">EXP</span>`
        : s.badge === 'helm' ? `<span class="badge helm">⛑</span>`
        : s.badge === 'sprout' ? `<span class="badge sprout"></span>` : '';
      const foot = locked
        ? `<span class="lock"><em>${s.lv}</em> Mở khóa</span>`
        : `<span class="cost"><i class="ic ic-coin"></i>${num(s.price)}</span>`;
      return `<div class="seed-cell r${s.r} ${locked ? 'locked' : ''} ${s.id === selSeed ? 'sel' : ''}"
        data-s="${s.id}">${badge}<img class="pack" src="${A.icon(s.art, 0)}" alt="">${foot}</div>`;
    }).join('');
    $$('#seedGrid .seed-cell').forEach(el => el.addEventListener('click', () => {
      selSeed = el.dataset.s; renderSeeds();
    }));

    const s = D.SEED_BY_ID[selSeed];
    const locked = s.lv > S.lv;
    $('#sdArt').innerHTML = A.img(A.icon(s.art, 0));
    $('#sdName').innerHTML = s.name + ` <i class="ic ic-tag"></i>`;
    $('#sdPrice').textContent = num(s.price);
    $('#sdColors').textContent = s.colors + ' loại';
    $('#sdXp').textContent = s.xp;
    $('#sdEn').textContent = s.en;
    $('#sdSell').textContent = num(GS.sellPrice(s.id, 0));
    $('#sdTime').textContent = FARM.fmt(GS.growTime(s));

    const q = +$('#qRange').value;
    $('#qtyVal').textContent = q;
    $('#buyTotal').textContent = num(s.price * q);
    $('#btnBuySeed').disabled = locked;
    if (locked) $('#buyTotal').textContent = 'Cấp ' + s.lv;
  }

  function buySeed() {
    const s = D.SEED_BY_ID[selSeed];
    if (!s || s.lv > S.lv) return toast('Chưa mở khóa hạt giống này');
    const q = +$('#qRange').value;
    const cost = s.price * q;
    if (S.coin < cost) return toast('Không đủ xu nông trại');
    GS.addCoin(-cost); GS.addSeed(s.id, q);
    renderHUD(); renderSeeds(); GS.save();
    toast(`Đã mua ${q} gói ${s.name}`);
  }

  /* ============================================================
     FRIENDS
     ============================================================ */
  function renderFriends() {
    $$('#frTabs .stab').forEach(b => b.classList.toggle('active', b.dataset.tab === frTab));
    const listEl = $('#frList');

    if (frTab === 'prof') {
      listEl.innerHTML = `<div class="fr-row"><div class="fr-av"><img src="${A.PROP.haystack}" alt=""></div>
        <div class="fr-mid"><div class="fr-name">Trang trại của bạn</div>
        <div style="font-size:14px;color:#7a5230">Cấp ${S.lv} · ${GS.maxPlots()} ô đất · ${GS.collectedCount()} bộ sưu tập</div></div></div>
        <div class="fr-row"><div class="fr-av"><img src="${A.crop('grape')}" alt=""></div>
        <div class="fr-mid"><div class="fr-name">Tài sản</div>
        <div style="font-size:14px;color:#7a5230">${num(S.coin)} xu · ${num(S.energy)} năng lượng thần kỳ</div></div></div>
        <div class="fr-row"><div class="fr-av"><img src="${A.crop('corn')}" alt=""></div>
        <div class="fr-mid"><div class="fr-name">Thống kê</div>
        <div style="font-size:14px;color:#7a5230">Thu hoạch ${S.stats.harvest} · Gieo ${S.stats.plant} · Tưới ${S.stats.water} · Đột biến ${S.stats.mutate}</div></div></div>`;
      $('#frSteal').textContent = (20 - S.stealLeft) + ' / 20';
      return;
    }

    const pool = frTab === 'add' ? D.FRIENDS.slice(3) : D.FRIENDS.slice(0, 3);
    listEl.innerHTML = pool.map(f => {
      const used = !!S.visited[f.id];
      const add = frTab === 'add';
      return `<div class="fr-row">
        <div class="fr-av"><img src="${A.crop(f.av)}" alt=""></div>
        <div class="fr-mid">
          <div class="fr-name"><span class="fr-lv">${f.lv}</span>${f.name}</div>
          ${add ? `<span class="fr-tag no">Chưa kết bạn</span>`
                : `<span class="fr-tag ${used ? 'no' : ''}">${used ? 'Đã trộm hôm nay' : 'Có thể trộm'}</span>`}
        </div>
        <button class="fr-visit" data-f="${f.id}">
          <span class="vi"><i class="ic ${add ? 'ic-friends' : 'ic-house'}"></i></span>
          <em>${add ? 'Kết bạn' : 'Thăm nom'}</em>
        </button>
      </div>`;
    }).join('');

    $$('#frList .fr-visit').forEach(b => b.addEventListener('click', () => visit(b.dataset.f)));
    $('#frSteal').textContent = (20 - S.stealLeft) + ' / 20';
  }

  function visit(id) {
    if (frTab === 'add') { toast('Đã gửi lời mời kết bạn'); return; }
    if (S.visited[id]) return toast('Hôm nay bạn đã thăm người này rồi');
    if (S.stealLeft <= 0) return toast('Hết lượt lấy cây trồng hôm nay');
    S.visited[id] = Date.now(); S.stealLeft--;

    const f = D.FRIENDS.find(x => x.id === id);
    const pool = D.SEEDS.filter(s => s.lv <= Math.max(1, f.lv));
    const pick = pool[Math.floor(Math.random() * pool.length)] || D.SEEDS[0];
    const v = Math.random() < 0.25 ? 1 + Math.floor(Math.random() * 7) : 0;
    const coin = 400 + Math.floor(Math.random() * 900);

    GS.addProduce(pick.id, v, 1);
    GS.addCoin(coin);
    GS.addEnergy(GS.energyGain(4));
    GS.track('visit', 1);
    renderHUD(); renderFriends(); GS.save();

    reward('Thăm nom ' + f.name, [
      { art: `<img src="${A.icon(pick.art, v)}" alt="">`, label: pick.name },
      { ic: 'ic-coin', label: '+' + num(coin) }]);
  }

  /* ============================================================
     SHOP (fullscreen)
     ============================================================ */
  function renderShop() {
    $$('#shopTabs .ptab').forEach(b => b.classList.toggle('active', b.dataset.tab === shopTab));
    const items = shopTab === 'coin' ? D.SHOP_COIN : D.SHOP_GOODS;
    let html = '';
    if (shopTab === 'coin') {
      html += `<div class="shop-hero">
        <div class="hero-art"><span><img src="${A.crop('cheese')}" alt=""></span><span><img src="${A.crop('bread')}" alt=""></span><span><img src="${A.crop('honey')}" alt=""></span></div>
        <div class="hero-foot">
          <div class="hf-txt"><small>1/1 có thể mua</small><b>Rương trang phục chọn 1</b></div>
          <div class="hf-ok">✓ Được giúp</div>
        </div></div>`;
    }
    html += items.map(it => {
      const bought = !!S.shopBought?.[it.id];
      return `<div class="shop-card ${bought ? 'sold' : ''}" data-b="${it.id}">
        <div class="timer"><i class="clk"></i>${it.time}</div>
        <div class="art"><div class="thumb"><img src="${A.crop(it.art)}" alt=""></div></div>
        <div class="cap">${it.name}<em>${it.sub}</em></div>
        <div class="price"><i class="ic ic-coin"></i>${num(it.price)}</div>
      </div>`;
    }).join('');
    $('#shopBody').innerHTML = html;
    $$('#shopBody [data-b]').forEach(el => el.addEventListener('click', () => buyShop(el.dataset.b)));
  }

  function buyShop(id) {
    const it = D.SHOP_COIN.concat(D.SHOP_GOODS).find(x => x.id === id);
    if (!it) return;
    S.shopBought = S.shopBought || {};
    if (S.shopBought[id]) return toast('Bạn đã mua vật phẩm này');
    if (S.coin < it.price) return toast('Không đủ xu nông trại');
    GS.addCoin(-it.price);

    let extra = [];
    switch (it.effect) {
      case 'energy': GS.addEnergy(300); extra.push({ ic: 'ic-sprout', label: '+300 NL' }); break;
      case 'plot': GS.unlockExtraPlot(); FARM.renderAll(); extra.push({ ic: 'ic-box', label: '+1 ô đất' }); break;
      case 'mutate': S.buffMutateUntil = Date.now() + 300000; extra.push({ ic: 'ic-sprout', label: '+30% ĐB' }); break;
      case 'seedbag': {
        const pool = D.SEEDS.filter(s => s.lv <= S.lv);
        for (let k = 0; k < 5; k++) {
          const p = pool[Math.floor(Math.random() * pool.length)] || D.SEEDS[0];
          GS.addSeed(p.id, 1);
        }
        extra.push({ ic: 'ic-seed', label: '5 hạt giống' }); break;
      }
      case 'instant': {
        const i = S.plots.findIndex(p => p && p.crop && FARM.plotState(p) !== 'ready');
        if (i >= 0) FARM.instantGrow(i);
        extra.push({ ic: 'ic-sprout', label: 'Chín ngay' }); break;
      }
      case 'water3': {
        let n = 0; for (let i = 0; i < 16 && n < 3; i++) if (FARM.water(i)) n++;
        extra.push({ ic: 'ic-sprout', label: 'Tưới x' + n }); break;
      }
      default: S.shopBought[id] = true;
    }
    if (!it.effect) S.shopBought[id] = true;

    renderHUD(); renderShop(); GS.save();
    reward('Mua thành công', [{ art: A.img(A.crop(it.art)), label: it.name }].concat(extra));
  }

  /* ============================================================
     COLLECTION (fullscreen)
     ============================================================ */
  function renderCollection() {
    $('#collectBody').innerHTML = D.COLLECTIONS.map(set => {
      const have = set.items.filter(it => S.collected[it.crop + ':' + it.v]).length;
      const full = have >= set.items.length;
      const claimed = !!S.claimedSets[set.id];
      return `<div class="col-set ${full ? 'done' : ''}">
        <button class="col-gift ${full && !claimed ? '' : 'dim'}" data-set="${set.id}"><img src="${A.crop('honey')}" alt=""></button>
        <h4>${set.name}<b>${have}/${set.items.length}</b></h4>
        <div class="col-items">${set.items.map(it => {
          const got = S.collected[it.crop + ':' + it.v];
          const s = D.SEED_BY_ID[it.crop];
          return `<div class="col-item ${got ? '' : 'locked'}">
            <div class="box"><img src="${A.icon(s.art, it ? it.v : 0)}" alt="" style="filter:${A.variantFilter(s.art, it.v)}"></div>
            <em>${got ? it.name : 'Mở khóa'}</em></div>`;
        }).join('')}</div></div>`;
    }).join('');

    $$('#collectBody [data-set]').forEach(b => b.addEventListener('click', () => claimSet(b.dataset.set)));

    const total = GS.collectedCount();
    $('#cfNum').textContent = total;
    $('#cfTrack').innerHTML = D.COLLECT_MILESTONES.map((m, i) => {
      const on = total >= m;
      const left = (i + 1) / (D.COLLECT_MILESTONES.length + 0.6) * 100;
      return `<div class="cf-node ${on ? 'on' : ''}" style="left:${left}%">${on ? '' : '<img src=\"' + A.crop('honey') + '\" alt=\"\">'}<em>${m}</em></div>`;
    }).join('');
  }

  function claimSet(id) {
    const set = D.COLLECTIONS.find(s => s.id === id);
    const have = set.items.filter(it => S.collected[it.crop + ':' + it.v]).length;
    if (have < set.items.length) return toast(`Còn thiếu ${set.items.length - have} vật phẩm`);
    if (S.claimedSets[id]) return toast('Bạn đã nhận thưởng bộ này');
    S.claimedSets[id] = true;
    GS.addCoin(set.reward.coin); GS.addXp(set.reward.xp);
    renderHUD(); renderCollection(); GS.save();
    reward('Hoàn thành ' + set.name, [
      { ic: 'ic-coin', label: '+' + num(set.reward.coin) },
      { ic: 'ic-xp', label: '+' + num(set.reward.xp) }]);
  }

  function claimAllMilestones() {
    const total = GS.collectedCount();
    let coin = 0, n = 0;
    D.COLLECT_MILESTONES.forEach(m => {
      if (total >= m && !S.claimedMs[m]) { S.claimedMs[m] = true; coin += m * 500; n++; }
    });
    D.COLLECTIONS.forEach(set => {
      const have = set.items.filter(it => S.collected[it.crop + ':' + it.v]).length;
      if (have >= set.items.length && !S.claimedSets[set.id]) {
        S.claimedSets[set.id] = true; coin += set.reward.coin; GS.addXp(set.reward.xp); n++;
      }
    });
    if (!n) return toast('Chưa có phần thưởng nào để nhận');
    GS.addCoin(coin); renderHUD(); renderCollection(); GS.save();
    reward('Nhận thưởng', [{ ic: 'ic-coin', label: '+' + num(coin) }, { ic: 'ic-book', label: n + ' mốc' }]);
  }

  global.UI = {
    open, close, refresh, renderHUD, toast, reward, closeReward, setDirtyHook, payout, openPlot, closePop,
    doUpgrade, openChests, sellAll, buySeed, harvestAll, plantAll,
    claimAllMilestones, renderSeeds, renderMissions, renderWarehouse, renderFriends, renderShop,
    setTab: (k, v) => { ({ ms: () => msTab = v, wh: () => whTab = v, fr: () => frTab = v, shop: () => shopTab = v })[k](); refresh(); },
    chapter: d => { chapIdx += d; renderMissions(); }
  };
})(window);
