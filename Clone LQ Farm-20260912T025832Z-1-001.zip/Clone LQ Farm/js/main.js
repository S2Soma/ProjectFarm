/* ============================================================
   main.js — boot, responsive scaling, input wiring, game loop
   ============================================================ */
(function (global) {
  'use strict';
  const GS = global.GS, FARM = global.FARM, UI = global.UI, ANIM = global.ANIM;
  const S = GS.S;
  const $ = s => document.querySelector(s);
  const $$ = s => Array.prototype.slice.call(document.querySelectorAll(s));

  /* ---------- fit the 1200x540 stage to any screen ----------
     Explicit translate+scale from the top-left corner: grid/flex
     centring mis-aligns once the un-scaled box is wider than the
     viewport. */
  /* 2.22:1 was taller than any common phone, so an 18% black bar sat above
     and below on the owner's 1.83 screen. 1.94:1 sits inside the real range
     (1.78-2.22) and the wrapper paints sky instead of black. */
  const BASE_W = 1200, BASE_H = 620;
  function fit() {
    const w = window.innerWidth, h = window.innerHeight;
    const sc = Math.min(w / BASE_W, h / BASE_H);
    const tx = (w - BASE_W * sc) / 2, ty = (h - BASE_H * sc) / 2;
    $('#stage').style.transform = `translate(${tx}px,${ty}px) scale(${sc})`;
  }
  window.addEventListener('resize', fit);
  window.addEventListener('orientationchange', () => setTimeout(fit, 200));
  if (window.visualViewport) window.visualViewport.addEventListener('resize', fit);

  /* ---------- wiring ---------- */
  function wire() {
    $('#btnShop').onclick = () => UI.open('shop');
    $('#btnMagic').onclick = () => UI.open('magic');
    $('#btnMissions').onclick = () => UI.open('missions');
    $('#btnUpgrade').onclick = () => UI.open('upgrade');
    $('#btnSeeds').onclick = () => UI.open('seeds');
    $('#btnFriends').onclick = () => UI.open('friends');
    $('#btnCollection').onclick = () => UI.open('collection');
    $('#btnWarehouse').onclick = () => UI.open('warehouse');
    $('#btnCoin').onclick = () => UI.open('shop');
    /* a control labelled "Quay lại" must not change game state */
    $('#btnBackTop').onclick = () => { UI.close(); UI.closeReward(); UI.closePop(); };

    $$('[data-close]').forEach(b => b.onclick = UI.close);
    $('#overlay').addEventListener('click', ev => { if (ev.target.id === 'overlay') UI.close(); });
    document.addEventListener('click', ev => {
      if (!ev.target.closest('.plot') && !ev.target.closest('.plot-pop')) UI.closePop();
    });

    $('#btnDoUpgrade').onclick = UI.doUpgrade;
    /* Hover-to-open plus click-to-toggle cancelled each other out: a real
       mouse click fires pointerenter (opens) then click (toggles shut), so
       the tooltip never stayed visible. Click alone, dismissed by the next
       click anywhere. */
    const tip = $('#upTip'), tipBtn = $('#upInfoBtn');
    tipBtn.addEventListener('click', e => {
      e.stopPropagation();
      tip.classList.toggle('on');
    });
    document.addEventListener('click', e => {
      if (!e.target.closest('#upInfoBtn')) tip.classList.remove('on');
    });

    $('#btnOpenChest').onclick = UI.openChests;

    $$('#msTabs .stab').forEach(b => b.onclick = () => UI.setTab('ms', b.dataset.tab));
    $('#chPrev').onclick = () => UI.chapter(-1);
    $('#chNext').onclick = () => UI.chapter(1);

    $$('#whTabs .stab').forEach(b => b.onclick = () => UI.setTab('wh', b.dataset.tab));
    $('#btnSellAll').onclick = UI.sellAll;

    $('#btnBuySeed').onclick = UI.buySeed;
    $('#qRange').oninput = UI.renderSeeds;
    $('#qMinus').onclick = () => { const r = $('#qRange'); r.value = Math.max(1, +r.value - 1); UI.renderSeeds(); };
    $('#qPlus').onclick = () => { const r = $('#qRange'); r.value = Math.min(+r.max, +r.value + 1); UI.renderSeeds(); };

    $$('#frTabs .stab').forEach(b => b.onclick = () => UI.setTab('fr', b.dataset.tab));
    $$('#shopTabs .ptab').forEach(b => b.onclick = () => UI.setTab('shop', b.dataset.tab));
    $('#btnClaimAll').onclick = UI.claimAllMilestones;

    $('#rwOk').onclick = () => UI.closeReward();
    $('#rewardModal').addEventListener('click', ev => {
      if (ev.target.id === 'rewardModal') UI.closeReward();
    });

    ANIM.bindPress(document);
    ANIM.bindRipple(document);

    document.addEventListener('keydown', e => {
      if (e.key === 'Escape') { UI.close(); UI.closeReward(); }
      if (e.key === 'h') UI.harvestAll();
      if (e.key === 'p') UI.plantAll();
    });
  }

  /* ---------- game loop ----------
     The loop only refreshes plots that are actively counting down,
     and each of those writes a single text node. Everything else
     (artwork, auras, badges) is event-driven. */
  let lastSec = 0, lastSave = 0, ticking = [], tickingDirty = true;

  function markTickingDirty() { tickingDirty = true; }

  function loop(ts) {
    requestAnimationFrame(loop);

    // one update per second is enough for a seconds-resolution countdown
    if (ts - lastSec < 1000) return;
    lastSec = ts;

    if (tickingDirty) { ticking = FARM.tickingPlots(); tickingDirty = false; }

    let finished = false;
    for (let k = 0; k < ticking.length; k++) {
      const i = ticking[k];
      FARM.renderPlot(i);
      if (FARM.plotState(S.plots[i]) !== 'growing') finished = true;
    }
    if (finished) tickingDirty = true;

    UI.renderHUD();
    if (ts - lastSave > 5000) { lastSave = ts; GS.save(); }
  }

  /* ---------- boot ---------- */
  function boot() {
    GS.load();
    fit();
    const A = global.ASSETS;
    const put = (sel, src) => { const e = $(sel); if (e && src) e.innerHTML = A.img(src); };
    put('#avatarPic', A.UI.portrait);
    $('#avatarBox').style.backgroundImage = 'url(' + A.UI.avatarRing + ')';
    put('#icoShop', A.UI.navShop);
    put('#icoChest', A.UI.badgeChest);
    put('#icoHouse', A.UI.navHome);
    put('#icoSeed', A.UI.navBag);
    put('#icoFriend', A.UI.navFriends);
    put('#icoBook', A.UI.navTrophy);
    put('#icoCoin', A.UI.icLeaf);
    put('#icoWater', A.UI.icCan);
    put('#collectHero', A.UI.badgeCrown);
    FARM.buildScenery();
    FARM.buildGrid();
    FARM.renderAll();
    wire();
    UI.setDirtyHook(markTickingDirty);
    UI.renderHUD(true);
    requestAnimationFrame(loop);

    // fade the loading veil once the first frame is painted
    requestAnimationFrame(() => requestAnimationFrame(() => {
      document.body.classList.add('ready');
    }));

    if (!S.stats.plant && !S.stats.harvest) {
      setTimeout(() => UI.toast('Chạm vào ô đất để gieo hạt giống!'), 900);
    }
    window.addEventListener('beforeunload', GS.save);
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') { markTickingDirty(); FARM.renderAll(); }
    });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();

  global.FARMDEV = {
    reset: () => { GS.reset(); location.reload(); },
    give: (c, x) => { GS.addCoin(c || 100000); GS.addXp(x || 0); UI.renderHUD(); GS.save(); },
    lv: n => { S.lv = n; GS.syncPlots(); FARM.renderAll(); UI.renderHUD(); GS.save(); },
    dirty: markTickingDirty
  };
})(window);
