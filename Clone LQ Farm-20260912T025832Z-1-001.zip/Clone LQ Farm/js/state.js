/* ============================================================
   state.js — game state, persistence, economy rules
   ============================================================ */
(function (global) {
  'use strict';
  const D = global.DATA;
  const KEY = 'lqfarm.save.v1';

  const S = {
    lv: 1, xp: 0,
    coin: 5000,
    energy: 0,
    plots: [],          // {crop,plantedAt,dur,watered,variant,ready,locked}
    seeds: {},          // seedId -> count
    store: {},          // "cropId:variant" -> count  (harvested produce)
    chests: [0, 0, 0, 0],
    missions: {},       // taskId -> {p:progress, claimed:bool}
    daily: {},
    collected: {},      // "cropId:variant" -> true
    claimedSets: {},
    claimedMs: {},
    stats: { harvest: 0, plant: 0, water: 0, sell: 0, chest: 0, visit: 0, mutate: 0, harvestBy: {}, sellBy: {} },
    visited: {},        // friendId -> timestamp
    stealLeft: 20,
    day: 0,
  };

  /* ------------ derived ------------ */
  function info() { return D.levelInfo(S.lv); }
  function xpNeed() { return info().xpNeed; }
  function maxPlots() { return info().plots; }

  /* An elemental crop is worth a multiple of the plain one; the
     multipliers live with the art in ASSETS.ELEM so the economy and
     the sprite sheet can never drift apart. */
  function elemInfo(v) { return global.ASSETS.ELEM[v] || global.ASSETS.ELEM[0]; }

  function sellPrice(cropId, variant) {
    const s = D.SEED_BY_ID[cropId];
    if (!s) return 0;
    return Math.round(s.sell * (1 + info().priceUp) * elemInfo(variant).sell);
  }
  function xpFor(seed, variant) { return Math.round(seed.xp * elemInfo(variant).xp); }
  function energyFor(seed, variant) {
    return Math.round(energyGain(seed.en) * elemInfo(variant).energy);
  }
  function growTime(seed) {
    return Math.max(6, Math.round(seed.grow * (1 - info().growCut)));
  }
  function mutateChance() {
    return info().mutate + (S.buffMutateUntil > Date.now() ? 0.3 : 0);
  }
  function energyGain(base) {
    return Math.round(base * (1 + info().energyUp));
  }

  /* ------------ mutations ------------
     One roll decides whether the crop mutates at all; a second picks
     which element, weighted so lightning stays the rare one. */
  function rollVariant() {
    if (Math.random() >= mutateChance()) return 0;
    const E = global.ASSETS.ELEM;
    let r = Math.random(), acc = 0;
    for (let v = 1; v < E.length; v++) {
      acc += E[v].chance;
      if (r < acc) return v;
    }
    return 1;
  }

  /* ------------ currency ------------ */
  function addCoin(n) { S.coin = Math.max(0, S.coin + n); }
  /* XP accumulates; it never levels the farm on its own.

     The old while-loop consumed the bar and incremented S.lv on every gain,
     which left S.xp < xpNeed() immediately afterwards — so the coin-gated
     "Nâng cấp trang trại" button could never satisfy its own precondition
     and stayed grey forever, while levels (and the plots and seeds tied to
     them) climbed for free. Levelling is now exactly what that button does. */
  function addXp(n) {
    S.xp += n;
    return 0;
  }

  /* spend a full bar plus the coin cost to gain a level */
  function levelUp() {
    const a = info();
    if (S.xp < a.xpNeed || S.coin < a.cost) return false;
    S.xp -= a.xpNeed;
    S.coin -= a.cost;
    S.lv++;
    syncPlots();
    track('level', 0, S.lv);
    return true;
  }
  function addEnergy(n) {
    S.energy += n;
    // energy rolls over into chest tiers
    D.CHESTS.forEach((c, i) => {
      while (S.energy >= c.need && i === chestTier()) {
        S.energy -= c.need; S.chests[i]++;
      }
    });
    if (S.energy > 99999) S.energy = 99999;
  }
  function chestTier() {
    // which chest the bar is currently filling: scales with farm level
    if (S.lv >= 20) return 3;
    if (S.lv >= 12) return 2;
    if (S.lv >= 6) return 1;
    return 0;
  }
  function energyGoal() { return D.CHESTS[chestTier()].need; }

  /* ------------ inventory ------------ */
  function addSeed(id, n) { S.seeds[id] = (S.seeds[id] || 0) + n; }
  function takeSeed(id, n) {
    if ((S.seeds[id] || 0) < n) return false;
    S.seeds[id] -= n; if (!S.seeds[id]) delete S.seeds[id];
    return true;
  }
  function addProduce(cropId, variant, n) {
    const k = cropId + ':' + variant;
    S.store[k] = (S.store[k] || 0) + (n || 1);
    if (!S.collected[k]) { S.collected[k] = true; track('collect', 1); }
  }
  function storeList() {
    return Object.entries(S.store).map(([k, n]) => {
      const [crop, v] = k.split(':');
      return { key: k, crop, v: +v, n, price: sellPrice(crop, +v) };
    }).sort((a, b) => b.price * b.n - a.price * a.n);
  }
  function collectedCount() { return Object.keys(S.collected).length; }

  /* ------------ plots ------------ */
  /* plots open outward from the middle of the 4x4 field, so the
     farm always reads as a block rather than a ragged L */
  const UNLOCK_ORDER = [5, 6, 9, 10, 4, 7, 1, 2, 13, 14, 8, 11, 0, 3, 12, 15];

  function syncPlots() {
    while (S.plots.length < 16) S.plots.push({ locked: true });
    const want = maxPlots();
    const open = new Set(UNLOCK_ORDER.slice(0, want));
    S.plots.forEach((p, i) => { if (open.has(i)) p.locked = false; });
  }
  /* `want` unlocks that exact tile — the player pays for the one they
     tapped. Without it the next tile in UNLOCK_ORDER opened instead and
     the tapped plot stayed locked. */
  function unlockExtraPlot(want) {
    if (want != null && S.plots[want] && S.plots[want].locked) {
      S.plots[want].locked = false;
      return true;
    }
    const i = UNLOCK_ORDER.find(k => S.plots[k] && S.plots[k].locked);
    if (i === undefined) return false;
    S.plots[i].locked = false;
    return true;
  }

  /* ------------ mission tracking ------------ */
  function track(type, amount, absolute) {
    const st = S.stats;
    if (type in st && typeof st[type] === 'number') st[type] += (amount || 0);

    D.CHAPTERS.forEach(ch => ch.tasks.forEach(t => {
      if (t.type !== type) return;
      const rec = S.missions[t.id] || (S.missions[t.id] = { p: 0, claimed: false });
      if (rec.claimed) return;
      if (type === 'level') rec.p = S.lv;
      else if (t.crop) { /* crop-specific handled in trackCrop */ }
      else rec.p = Math.min(t.need, rec.p + (amount || 0));
    }));
    D.DAILY.forEach(t => {
      if (t.type !== type) return;
      const rec = S.daily[t.id] || (S.daily[t.id] = { p: 0, claimed: false });
      if (rec.claimed) return;
      rec.p = Math.min(t.need, rec.p + (amount || 0));
    });
  }

  function trackCrop(type, cropId, amount) {
    track(type, amount);
    D.CHAPTERS.forEach(ch => ch.tasks.forEach(t => {
      if (t.type !== type || t.crop !== cropId) return;
      const rec = S.missions[t.id] || (S.missions[t.id] = { p: 0, claimed: false });
      if (!rec.claimed) rec.p = Math.min(t.need, rec.p + (amount || 1));
    }));
  }

  function taskProgress(t, daily) {
    const bag = daily ? S.daily : S.missions;
    const rec = bag[t.id] || { p: 0, claimed: false };
    if (t.type === 'level') return { p: Math.min(t.need, S.lv), claimed: rec.claimed };
    if (t.type === 'collect') return { p: Math.min(t.need, collectedCount()), claimed: rec.claimed };
    return { p: Math.min(t.need, rec.p), claimed: rec.claimed };
  }

  function claimTask(t, daily) {
    const bag = daily ? S.daily : S.missions;
    const pr = taskProgress(t, daily);
    if (pr.claimed || pr.p < t.need) return false;
    (bag[t.id] || (bag[t.id] = { p: pr.p, claimed: false })).claimed = true;
    bag[t.id].p = t.need;
    addCoin(t.coin); addXp(t.xp);
    return true;
  }

  function activeMission() {
    for (const ch of D.CHAPTERS) {
      for (const t of ch.tasks) {
        const pr = taskProgress(t, false);
        if (!pr.claimed) return { t, pr };
      }
    }
    return null;
  }

  /* ------------ daily reset ------------ */
  function checkDay() {
    const d = Math.floor(Date.now() / 86400000);
    if (S.day !== d) {
      S.day = d; S.daily = {}; S.stealLeft = 20; S.visited = {};
    }
  }

  /* ------------ persistence ------------ */
  function save() {
    try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) { /* ignore */ }
  }
  function load() {
    let raw = null;
    try { raw = localStorage.getItem(KEY); } catch (e) { /* ignore */ }
    if (raw) {
      try { Object.assign(S, JSON.parse(raw)); } catch (e) { /* ignore */ }
    } else {
      seedNewGame();
    }
    if (!S.plots || !S.plots.length) S.plots = [];
    pruneUnknown();
    syncPlots();
    checkDay();
    if (!Object.keys(S.seeds).length && !S.stats.plant) seedStarter();
  }
  /* a save from an older crop roster can hold ids that no longer exist;
     drop them so planting and selling never hit an undefined seed */
  function pruneUnknown() {
    Object.keys(S.seeds).forEach(id => { if (!D.SEED_BY_ID[id]) delete S.seeds[id]; });
    Object.keys(S.store).forEach(k => { if (!D.SEED_BY_ID[k.split(':')[0]]) delete S.store[k]; });
    Object.keys(S.collected).forEach(k => { if (!D.SEED_BY_ID[k.split(':')[0]]) delete S.collected[k]; });
    S.plots.forEach(p => { if (p && p.crop && !D.SEED_BY_ID[p.crop]) { p.crop = null; p.variant = 0; } });
  }

  function seedStarter() { S.seeds = { carrot: 6, wheat: 4, tomato: 2 }; }

  function seedNewGame() {
    S.lv = 1; S.xp = 0; S.coin = 5000; S.energy = 0;
    seedStarter();
    S.plots = [];
    syncPlots();
  }
  function reset() { try { localStorage.removeItem(KEY); } catch (e) {} seedNewGame(); }

  global.GS = {
    S, info, xpNeed, maxPlots, sellPrice, growTime, mutateChance, energyGain, rollVariant,
    addCoin, addXp, levelUp, addEnergy, chestTier, energyGoal, elemInfo, xpFor, energyFor,
    addSeed, takeSeed, addProduce, storeList, collectedCount,
    syncPlots, unlockExtraPlot, pruneUnknown,
    track, trackCrop, taskProgress, claimTask, activeMission,
    save, load, reset, checkDay
  };
})(window);
