/* ============================================================
   assets.js — image registry

   assets/farm/  plot tiles, crop growth stages and scenery props
   assets/ui/    HUD and panel chrome
   assets/crop/  produce icons for crops without painted art
   See assets/CREDITS.txt.
   ============================================================ */
(function (global) {
  'use strict';

  const BASE = 'assets/';
  const crop = id => BASE + 'crop/' + id + '.png';
  const farm = id => BASE + 'farm/' + id + '.png';
  const ui = id => BASE + 'ui/' + id + '.png';

  /* ---- plot tiles ----
     All four are exported on one 390x320 canvas with the isometric
     diamond 380px wide and its axis at 52.5% of the height, so
     swapping states never nudges the tile. */
  const TILE = {
    empty: farm('tile_empty'),
    locked: farm('tile_locked'),
    watered: farm('tile_watered'),
    ready: farm('tile_ready')
  };
  const TILE_AXIS = 52.5;

  /* ============================================================
     MUTATIONS
     A crop can come up in one of four elements. Ice/fire/lightning
     are rarer and worth progressively more.
     ============================================================ */
  const ELEM = [
    { id: 0, key: '',      name: 'Thường',   short: '',      chance: 0,
      sell: 1,   xp: 1,   energy: 1,   glow: null },
    { id: 1, key: '_ice',  name: 'Băng Giá', short: 'Băng',  chance: 0.55,
      sell: 2.2, xp: 1.5, energy: 1.5, glow: '#6ec6ff' },
    { id: 2, key: '_fire', name: 'Viêm Hoả', short: 'Hoả',   chance: 0.30,
      sell: 3.5, xp: 2.0, energy: 2,   glow: '#ff7a3a' },
    { id: 3, key: '_bolt', name: 'Lôi Điện', short: 'Lôi',   chance: 0.15,
      sell: 5.0, xp: 3.0, energy: 3,   glow: '#ffd84a' }
  ];
  const elem = v => ELEM[v] || ELEM[0];

  /* crops whose sheet carries all four elements (3 painted stages) */
  const ELEMENTAL = ['wheat', 'potato', 'tomato'];
  /* crops with 4 painted stages but no elemental art */
  const STAGED = ['pumpkin', 'corn', 'carrot'];

  const isElemental = art => ELEMENTAL.indexOf(art) >= 0;
  const isStaged = art => STAGED.indexOf(art) >= 0;

  /* generic stages for every other crop — one species throughout */
  const GENERIC = [farm('tomato_1'), farm('tomato_2'), farm('tomato_3'), farm('tomato_3')];

  /* on-screen height per stage (px) */
  const STAGE_H = [46, 70, 96, 112];

  /* plant art for a crop at a growth stage (0-3) in an element */
  function plant(art, stage, v) {
    if (isElemental(art)) {
      // the elemental sheets have three stages; stage 3 reuses the ripe frame
      return farm(art + elem(v).key + '_' + Math.min(stage + 1, 3));
    }
    if (isStaged(art)) return farm(art + '_' + (stage + 1));
    return GENERIC[stage];
  }
  /* produce laid on the generic bush when ripe */
  function fruit(art) { return (isElemental(art) || isStaged(art)) ? null : crop(art); }
  /* inventory / shop icon */
  function icon(art, v) {
    if (isElemental(art)) return farm(art + elem(v).key + '_3');
    if (isStaged(art)) return farm(art + '_4');
    return crop(art);
  }

  /* Crops without painted elemental art are tinted. The rotation is
     measured from the foliage's own green (~100deg), not from red, so
     ice lands on blue and fire on orange — the old values put ice at
     magenta and left fire and lightning still green. */
  const TINT = [
    '',
    'hue-rotate(100deg) saturate(1.18) brightness(1.07)',   // băng
    'hue-rotate(272deg) saturate(1.28) brightness(1.03)',   // hoả
    'hue-rotate(308deg) saturate(1.32) brightness(1.09)'    // lôi
  ];
  function variantFilter(art, v) {
    if (!v || isElemental(art)) return '';
    return TINT[v] || '';
  }

  const PROP = {
    fence: farm('fence'), fenceLamp: farm('fence_lamp'),
    signpost: farm('signpost'), banner: farm('banner'),
    rock: farm('rock'), haystack: farm('haystack')
  };

  const UI = {
    panel: ui('panel'), plate: ui('plate'), titlebar: ui('titlebar'),
    profile: ui('profile'), avatarRing: ui('avatar_ring'), portrait: ui('portrait'),
    pillCoin: ui('pill_coin'), pillLeaf: ui('pill_leaf'), pillGem: ui('pill_gem'),
    barLeaf: ui('bar_leaf'), barGreen: ui('bar_green'), barYellow: ui('bar_yellow'),
    navHome: ui('nav_home'), navBag: ui('nav_bag'), navQuest: ui('nav_quest'),
    navFriends: ui('nav_friends'), navTrophy: ui('nav_trophy'), navShop: ui('nav_shop'),
    arrowBack: ui('arrow_back'), arrowPrev: ui('arrow_prev'), arrowNext: ui('arrow_next'),
    icHelp: ui('ic_help'), icStar: ui('ic_star'), icCan: ui('ic_can'),
    icBag: ui('ic_bag'), icCrate: ui('ic_crate'), icLeaf: ui('ic_leaf'),
    icSprout: ui('ic_sprout'), btnPlus: ui('btn_plus'),
    chipLeaf: ui('chip_leaf'), chipCan: ui('chip_can'), chipBag: ui('chip_bag'),
    chipCrate: ui('chip_crate'), chipSprout: ui('chip_sprout'),
    diaMap: ui('dia_map'), diaStar: ui('dia_star'), diaQuest: ui('dia_quest'),
    diaTool: ui('dia_tool'),
    rowBlue: ui('row_blue'), rowGreen: ui('row_green'), rowBrown: ui('row_brown'),
    badgeStar: ui('badge_star'), badgeCrown: ui('badge_crown'), badgeChest: ui('badge_chest'),
    flag: [ui('flag_green'), ui('flag_blue'), ui('flag_purple'), ui('flag_red')]
  };

  function img(src, cls, extra) {
    return `<img src="${src}" class="${cls || ''}" alt="" draggable="false"
      decoding="async"${extra ? ' ' + extra : ''}>`;
  }
  function preload(list) { list.forEach(s => { if (s) { const i = new Image(); i.src = s; } }); }

  global.ASSETS = {
    BASE, crop, farm, ui, TILE, TILE_AXIS,
    ELEM, elem, ELEMENTAL, STAGED, isElemental, isStaged,
    GENERIC, STAGE_H, plant, fruit, icon, variantFilter,
    PROP, UI, img, preload
  };
})(window);
