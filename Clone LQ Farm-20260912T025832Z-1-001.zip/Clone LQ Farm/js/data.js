/* ============================================================
   data.js — static game content
   ============================================================ */
(function (global) {
  'use strict';

  /* rarity: 0 thường (teal) | 1 hiếm (blue) | 2 sử thi (purple) | 3 huyền thoại (crimson)
     grow = seconds. `art` names a file in assets/crop/.                              */
  const SEEDS = [
    { id: 'carrot',     name: 'Cà Rốt',        art: 'carrot',     r: 0, lv: 1,  price: 0,    grow: 40,  xp: 8,   en: 2,  sell: 42,   colors: 4, badge: null },
    { id: 'wheat',      name: 'Lúa Mì',        art: 'wheat',      r: 0, lv: 1,  price: 83,   grow: 55,  xp: 12,  en: 2,  sell: 118,  colors: 4, badge: null },
    { id: 'tomato',     name: 'Cà Chua',       art: 'tomato',     r: 0, lv: 2,  price: 224,  grow: 80,  xp: 20,  en: 3,  sell: 268,  colors: 4, badge: null },
    { id: 'potato',     name: 'Khoai Tây',     art: 'potato',     r: 0, lv: 3,  price: 251,  grow: 92,  xp: 24,  en: 3,  sell: 302,  colors: 4, badge: null },
    { id: 'corn',       name: 'Ngô',           art: 'corn',       r: 0, lv: 4,  price: 298,  grow: 105, xp: 28,  en: 3,  sell: 352,  colors: 4, badge: null },

    { id: 'mushroom',   name: 'Nấm Rừng',      art: 'mushroom',   r: 1, lv: 5,  price: 137,  grow: 70,  xp: 42,  en: 4,  sell: 176,  colors: 4, badge: 'exp' },
    { id: 'leek',       name: 'Tỏi Tây',       art: 'leek',       r: 1, lv: 6,  price: 199,  grow: 96,  xp: 34,  en: 4,  sell: 246,  colors: 4, badge: null },
    { id: 'garlic',     name: 'Hành Bổ',       art: 'garlic',     r: 1, lv: 7,  price: 225,  grow: 110, xp: 38,  en: 4,  sell: 282,  colors: 4, badge: null },
    { id: 'broccoli',   name: 'Súp Lơ Xanh',   art: 'broccoli',   r: 1, lv: 8,  price: 247,  grow: 122, xp: 42,  en: 4,  sell: 312,  colors: 4, badge: null },
    { id: 'pepper',     name: 'Ớt Chuông',     art: 'pepper',     r: 1, lv: 9,  price: 266,  grow: 134, xp: 46,  en: 5,  sell: 338,  colors: 4, badge: null },
    { id: 'eggplant',   name: 'Cà Tím',        art: 'eggplant',   r: 1, lv: 10, price: 285,  grow: 146, xp: 50,  en: 5,  sell: 364,  colors: 4, badge: null },
    { id: 'cauliflower',name: 'Súp Lơ Trắng',  art: 'cauliflower',r: 1, lv: 11, price: 357,  grow: 168, xp: 58,  en: 5,  sell: 452,  colors: 4, badge: 'helm' },

    { id: 'pumpkin',    name: 'Bí Ngô',        art: 'pumpkin',    r: 2, lv: 12, price: 285,  grow: 150, xp: 62,  en: 6,  sell: 392,  colors: 4, badge: null },
    { id: 'radish',     name: 'Củ Cải',        art: 'radish',     r: 2, lv: 13, price: 385,  grow: 211, xp: 65,  en: 5,  sell: 406,  colors: 4, badge: 'sprout' },
    { id: 'beetroot',   name: 'Củ Dền',        art: 'beetroot',   r: 2, lv: 14, price: 412,  grow: 224, xp: 72,  en: 6,  sell: 528,  colors: 4, badge: 'helm' },
    { id: 'grape',      name: 'Nho Tím',       art: 'grape',      r: 2, lv: 15, price: 448,  grow: 240, xp: 96,  en: 6,  sell: 566,  colors: 4, badge: 'exp' },
    { id: 'cabbage',    name: 'Bắp Cải',       art: 'cabbage',    r: 2, lv: 16, price: 486,  grow: 258, xp: 84,  en: 7,  sell: 618,  colors: 4, badge: 'helm' },
    { id: 'lemon',      name: 'Chanh Vàng',    art: 'lemon',      r: 2, lv: 17, price: 522,  grow: 272, xp: 90,  en: 7,  sell: 664,  colors: 4, badge: 'helm' },
    { id: 'orange',     name: 'Cam',           art: 'orange',     r: 2, lv: 19, price: 604,  grow: 300, xp: 104, en: 8,  sell: 772,  colors: 4, badge: 'helm' },
    { id: 'pear',       name: 'Lê',            art: 'pear',       r: 2, lv: 21, price: 668,  grow: 318, xp: 112, en: 8,  sell: 856,  colors: 4, badge: 'helm' },

    { id: 'peach',      name: 'Táo Đỏ',        art: 'peach',      r: 3, lv: 22, price: 742,  grow: 340, xp: 126, en: 9,  sell: 962,  colors: 4, badge: 'helm' },
    { id: 'strawberry', name: 'Dâu Tây',       art: 'strawberry', r: 3, lv: 23, price: 806,  grow: 356, xp: 168, en: 9,  sell: 1042, colors: 4, badge: 'exp' },
    { id: 'cherries',   name: 'Anh Đào',       art: 'cherries',   r: 3, lv: 24, price: 874,  grow: 372, xp: 142, en: 10, sell: 1128, colors: 4, badge: 'helm' },
    { id: 'banana',     name: 'Chuối',         art: 'banana',     r: 3, lv: 25, price: 948,  grow: 392, xp: 152, en: 10, sell: 1224, colors: 4, badge: 'helm' },
    { id: 'watermelon', name: 'Dưa Hấu',       art: 'watermelon', r: 3, lv: 26, price: 1026, grow: 410, xp: 164, en: 11, sell: 1328, colors: 4, badge: 'helm' },
    { id: 'pineapple',  name: 'Dứa',           art: 'pineapple',  r: 3, lv: 28, price: 1120, grow: 430, xp: 176, en: 11, sell: 1440, colors: 4, badge: 'helm' },
    { id: 'coconut',    name: 'Dừa',           art: 'coconut',    r: 3, lv: 29, price: 1180, grow: 448, xp: 188, en: 12, sell: 1546, colors: 4, badge: 'sprout' },
    { id: 'avocado',    name: 'Bơ Sáp',        art: 'avocado',    r: 3, lv: 30, price: 1280, grow: 470, xp: 204, en: 12, sell: 1690, colors: 4, badge: 'helm' }
  ];

  const SEED_BY_ID = Object.fromEntries(SEEDS.map(s => [s.id, s]));

  /* ---------------- farm levels ----------------
     16 plots max; a new plot every few levels.                       */
  function levelInfo(lv) {
    return {
      xpNeed: Math.round(3600 * Math.pow(1.28, lv - 1)),
      growCut: Math.min(0.45, 0.01 * lv),          // thời gian chín được rút ngắn
      mutate: Math.min(0.45, 0.012 * lv + 0.06),   // xác suất đột biến
      priceUp: Math.min(1.2, 0.02 * lv + 0.06),    // giá nông sản tăng
      energyUp: Math.min(0.5, 0.004 * lv),         // tăng cường năng lượng kỳ diệu
      plots: Math.min(16, 9 + Math.floor((lv - 1) / 2)),
      cost: 10000 * lv + 5000
    };
  }

  /* ---------------- chests ---------------- */
  const CHESTS = [
    { id: 0, name: 'Rương thường',   need: 300,  cls: 't0',
      desc: 'Có 90% cơ hội nhận được xu nông trại và vật phẩm thông thường, 10% cơ hội nhận được hạt giống.' },
    { id: 1, name: 'Rương quý',      need: 600,  cls: 't1',
      desc: 'Có 80% cơ hội nhận được xu nông trại, vật phẩm thông thường và 20% cơ hội nhận được một vật phẩm hiếm.' },
    { id: 2, name: 'Rương thần kỳ',  need: 1200, cls: 't2',
      desc: 'Có 75% cơ hội nhận được xu nông trại, vật phẩm thông thường và 25% cơ hội nhận được một vật phẩm hiếm.' },
    { id: 3, name: 'Rương huyền thoại', need: 3000, cls: 't3',
      desc: 'Chắc chắn nhận được một vật phẩm hiếm cùng lượng lớn xu nông trại.' }
  ];

  /* ---------------- missions ---------------- */
  const CHAPTERS = [
    { name: 'Nông dân tập sự', tasks: [
      { id: 'c1a', t: 'Thu hoạch cà rốt', type: 'harvest', crop: 'carrot', need: 6,  xp: 800,  coin: 800 },
      { id: 'c1b', t: 'Gieo trồng bất kỳ', type: 'plant',  need: 10, xp: 800,  coin: 800 },
      { id: 'c1c', t: 'Tưới nước cho cây', type: 'water',  need: 8,  xp: 1000, coin: 1000 },
      { id: 'c1d', t: 'Đạt cấp độ trang trại', type: 'level', need: 4, xp: 1200, coin: 1500 }
    ]},
    { name: 'Người bán nông sản', tasks: [
      { id: 'c2a', t: 'Bán nông sản bất kỳ', type: 'sell', need: 20, xp: 2000, coin: 2000 },
      { id: 'c2b', t: 'Thu hoạch cà chua',   type: 'harvest', crop: 'tomato', need: 12, xp: 2000, coin: 2000 },
      { id: 'c2c', t: 'Mở rương thần kỳ',    type: 'chest', need: 3, xp: 2500, coin: 2500 },
      { id: 'c2d', t: 'Đạt cấp độ trang trại', type: 'level', need: 8, xp: 3000, coin: 3500 }
    ]},
    { name: 'Chuyên gia cây trồng', tasks: [
      { id: 'c3a', t: 'Thu hoạch khoai tây', type: 'harvest', crop: 'potato', need: 16, xp: 5000, coin: 5000 },
      { id: 'c3b', t: 'Khoai tây để bán',    type: 'sellCrop', crop: 'potato', need: 2,  xp: 5000, coin: 5000 },
      { id: 'c3c', t: 'Đạt cấp độ trang trại', type: 'level', need: 16, xp: 5000, coin: 5000 },
      { id: 'c3d', t: 'Thu hoạch cây đột biến', type: 'mutate', need: 5, xp: 6000, coin: 6000 }
    ]},
    { name: 'Bậc thầy nông trại', tasks: [
      { id: 'c4a', t: 'Thu hoạch ngô',       type: 'harvest', crop: 'corn', need: 24, xp: 9000, coin: 9000 },
      { id: 'c4b', t: 'Thăm nom bạn bè',     type: 'visit', need: 10, xp: 9000, coin: 9000 },
      { id: 'c4c', t: 'Thu thập bộ sưu tập', type: 'collect', need: 12, xp: 12000, coin: 12000 },
      { id: 'c4d', t: 'Đạt cấp độ trang trại', type: 'level', need: 25, xp: 15000, coin: 20000 }
    ]}
  ];

  const DAILY = [
    { id: 'd1', t: 'Thu hoạch 15 cây trồng', type: 'harvest', need: 15, xp: 1200, coin: 1200 },
    { id: 'd2', t: 'Tưới nước 10 lần',       type: 'water',   need: 10, xp: 1000, coin: 1000 },
    { id: 'd3', t: 'Gieo trồng 12 hạt giống',type: 'plant',   need: 12, xp: 1000, coin: 1000 },
    { id: 'd4', t: 'Bán 30 nông sản',        type: 'sell',    need: 30, xp: 1500, coin: 1800 },
    { id: 'd5', t: 'Thăm nom 5 người bạn',   type: 'visit',   need: 5,  xp: 1500, coin: 1500 }
  ];

  /* ---------------- shop ---------------- */
  const SHOP_COIN = [
    { id: 's1', name: 'Hoạt họa Siêu Đạo',   sub: '0/1 có thể mua', art: 'cheese', price: 19999, time: '22d 10h', big: false },
    { id: 's2', name: 'Hoạt họa Conan',      sub: '0/1 có thể mua', art: 'bread', price: 19999, time: '22d 10h', big: false },
    { id: 's3', name: 'Chân dung tội phạm',  sub: '0/1 có thể mua', art: 'egg', price: 19999, time: '22d 10h', big: false },
    { id: 's4', name: 'Mảnh ngọc bí ẩn',     sub: '0/50 có thể mua', art: 'grape', price: 1200,  time: '22d 10h', big: false },
    { id: 's5', name: 'Khung hình thám tử',  sub: '0/1 có thể mua',  art: 'salad', price: 8800,  time: '22d 10h', big: false },
    { id: 's6', name: 'Biểu cảm Kid',        sub: '0/1 có thể mua',  art: 'honey', price: 6600,  time: '22d 10h', big: false },
    { id: 's7', name: 'Rương bí ẩn',         sub: '0/1 có thể mua',  art: 'coconut', price: 15000, time: '31d 10h', big: false },
    { id: 's8', name: 'Huy hiệu Conan',      sub: '0/1 có thể mua',  art: 'lemon', price: 9900,  time: '22d 10h', big: false },
    { id: 's9', name: 'Bó hồng nông trại',   sub: '1/1 có thể mua',  art: 'cherries', price: 3500,  time: '22d 10h', big: false }
  ];

  const SHOP_GOODS = [
    { id: 'g1', name: 'Bình tưới vàng',   sub: 'Tưới nhanh x3',     art: 'lime', price: 2600,  time: '7d 0h', effect: 'water3' },
    { id: 'g2', name: 'Phân bón thần kỳ', sub: 'Chín ngay 1 ô',     art: 'avocado', price: 3800,  time: '7d 0h', effect: 'instant' },
    { id: 'g3', name: 'Bùa đột biến',     sub: '+30% đột biến 5 phút', art: 'watermelon', price: 5200, time: '7d 0h', effect: 'mutate' },
    { id: 'g4', name: 'Túi hạt ngẫu nhiên', sub: 'x5 hạt giống',    art: 'pineapple', price: 1900,  time: '7d 0h', effect: 'seedbag' },
    { id: 'g5', name: 'Năng lượng thần kỳ', sub: '+300 năng lượng', art: 'banana', price: 4400,  time: '7d 0h', effect: 'energy' },
    { id: 'g6', name: 'Mở rộng luống đất', sub: 'Mở 1 ô đất',       art: 'potato', price: 12000, time: '7d 0h', effect: 'plot' }
  ];

  /* ---------------- friends ---------------- */
  const FRIENDS = [
    { id: 'f1', name: 'Báo•Công-An',   lv: 9,  av: 'broccoli', color: '#4a9c6a' },
    { id: 'f2', name: 'Báo•ɵphụɞnữ✿',  lv: 10, av: 'peach', color: '#c98a3a' },
    { id: 'f3', name: 'Báo•Tuổi•Trẻ',  lv: 9,  av: 'grape', color: '#5a86c9' },
    { id: 'f4', name: 'Kaito•Kid',     lv: 12, av: 'cauliflower', color: '#7a5ac9' },
    { id: 'f5', name: 'Thám•Tử•Nhí',   lv: 11, av: 'mushroom', color: '#c95a6a' },
    { id: 'f6', name: 'Nông•Dân•Vui',  lv: 8,  av: 'orange', color: '#c9a83a' }
  ];

  /* ---------------- collection sets ---------------- */
  /* Sets are built around the four elements (0 thường, 1 băng,
     2 hoả, 3 lôi) so collecting means chasing mutations. */
  const COLLECTIONS = [
    { id: 'k1', name: 'Tứ Nguyên Lúa Mì', reward: { coin: 12000, xp: 3000 },
      items: [
        { crop: 'wheat', v: 0, name: 'Lúa Mì' },
        { crop: 'wheat', v: 1, name: 'Lúa Mì Băng' },
        { crop: 'wheat', v: 2, name: 'Lúa Mì Hoả' },
        { crop: 'wheat', v: 3, name: 'Lúa Mì Lôi' }
      ] },
    { id: 'k2', name: 'Tứ Nguyên Khoai Tây', reward: { coin: 14000, xp: 3600 },
      items: [
        { crop: 'potato', v: 0, name: 'Khoai Tây' },
        { crop: 'potato', v: 1, name: 'Khoai Tây Băng' },
        { crop: 'potato', v: 2, name: 'Khoai Tây Hoả' },
        { crop: 'potato', v: 3, name: 'Khoai Tây Lôi' }
      ] },
    { id: 'k3', name: 'Tứ Nguyên Cà Chua', reward: { coin: 16000, xp: 4200 },
      items: [
        { crop: 'tomato', v: 0, name: 'Cà Chua' },
        { crop: 'tomato', v: 1, name: 'Cà Chua Băng' },
        { crop: 'tomato', v: 2, name: 'Cà Chua Hoả' },
        { crop: 'tomato', v: 3, name: 'Cà Chua Lôi' }
      ] },
    { id: 'k4', name: 'Vườn Băng Giá', reward: { coin: 22000, xp: 5200 },
      items: [
        { crop: 'carrot', v: 1, name: 'Cà Rốt Băng' },
        { crop: 'corn', v: 1, name: 'Ngô Băng' },
        { crop: 'pumpkin', v: 1, name: 'Bí Ngô Băng' },
        { crop: 'grape', v: 1, name: 'Nho Băng' }
      ] },
    { id: 'k5', name: 'Vườn Lôi Điện', reward: { coin: 30000, xp: 7000 },
      items: [
        { crop: 'carrot', v: 3, name: 'Cà Rốt Lôi' },
        { crop: 'corn', v: 3, name: 'Ngô Lôi' },
        { crop: 'strawberry', v: 3, name: 'Dâu Tây Lôi' },
        { crop: 'watermelon', v: 3, name: 'Dưa Hấu Lôi' }
      ] }
  ];
  const COLLECT_MILESTONES = [6, 20, 45, 80];

  global.DATA = {
    SEEDS, SEED_BY_ID, levelInfo, CHESTS, CHAPTERS, DAILY,
    SHOP_COIN, SHOP_GOODS, FRIENDS, COLLECTIONS, COLLECT_MILESTONES
  };
})(window);
